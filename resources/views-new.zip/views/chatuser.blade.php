@extends('layouts.master')


     <script src="{{ asset('js/app.js') }}" defer></script>

@section('main-content')

            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor"><img src="{{ asset('backend/images/chat2.png') }}" alt="Report" title="Img"> Chats</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Chats</li>
                    </ol>
                </div>
                
            </div>
        
     <!-- ============================================================== -->
            <div class="container-fluid">
                
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                   @if($message)
                        <div class="alert alert-info">{{ @$message }}</div>
                    @endif
        	   
        		@if ( isthisSubscribed() || getmanualfeatures('token_monthly_connection_'))
        		   	<div class="mtop30">
            		    <chat-users v-on:fetchusers="fetchMessages" :chatnewusers="chatnewusers" :chatusers="chatusers"></chat-users>
            			<chat-messages v-on:messagesent="addMessage" v-on:fetchusers="fetchMessages" :user="{{ Auth::user() }}" :messages="messages"></chat-messages>
            		</div>
                @else
        	        @include('includes.debitTokens', ['featurevalue'=>'token_monthly_connection_value_','featureclass'=>'chat','featurename'=>'token_monthly_connection_', 'featureMessage'=>'Hey '. ucfirst( Auth::user()->name ) .'!. Upgrade your membership today to experience unlimited chat.'])
        	    @endif
        	</div>	

    <div class="chat_notify" id="notifyerror"><i class="fa fa-warning"></i> <span>Notification</span></div>

                   
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                             </div>
                        </div>
                    </div>
                </div>
            </div>
                 	

 

@endsection