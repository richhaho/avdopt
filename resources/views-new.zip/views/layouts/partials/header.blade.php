        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar">
           
            <nav class="  navbar top-navbar  navbar-fixed-top navbar-expand-md navbar-light">
                <!-- ============================================================== -->
                <!-- Logo -->
                <!-- ============================================================== -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="{{url('/')}}">
                        <!-- Logo icon --><b>
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            <!-- Dark Logo icon -->
                            <img src="{{ asset('assets/images/logo-icon.png')}}" alt="homepage" class="dark-logo" />
                            <!-- Light Logo icon -->
                            <img src="{{ asset('frontend/images/logo.png')}}" alt="homepage" class="light-logo" />
                        </b>
                        <!--End Logo icon -->
                        <!-- Logo text --> </a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav mr-auto mt-md-0">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link nav-toggler hidden-md-up text-muted waves-effect waves-dark" href="javascript:void(0)"><i class="mdi mdi-menu"></i></a> </li>
                        <!-- ============================================================== -->
                        <!-- Comment -->
                        <!-- ============================================================== -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted text-muted waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="mdi mdi-bell"></i>
                                <div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
                            </a>
                            <div class="dropdown-menu mailbox animated slideInUp">
                                <ul>
                                    <li>
                                        <div class="drop-title">Notifications</div>
                                    </li>
                                    <li>
                                        <div class="message-center">
                                             <!-- Message -->
                                            <a href="#">
                                                <div class="btn btn-danger btn-circle"></div>
                                                <div class="mail-contnet">
                                                    <h5>Luanch Admin</h5> <span class="mail-desc">message </span> <span class="time">9:30 AM</span> </div>
                                            </a>
                                            @php
                                 $notifications = getLatestNotification();
                             @endphp
                             @if( $notifications )
                                @foreach( $notifications as $notification )
                                    @switch($notification->type)
                                        @case('like')
                                            @php
                                                $userdata = \App\User::find($notification->created_by);
                                                $profilepic = ( @$userdata->profile_pic )? 'uploads/'. $userdata->profile_pic : 'images/default.png';
                                            @endphp
                                            @if( $userdata )
                                             <!-- Message -->
                                            <a href="{{url('userprofile')}}/{{ base64_encode($notification->created_by) }}" notify_id="{{ $notification->id }}">
                                                <div class="btn btn-danger btn-circle"></div>
                                                <div class="mail-contnet">
                                                    <h5>{{ $userdata->name }}</h5> <span class="mail-desc">{{ $notification->message }}</span> <span class="time">9:30 AM</span> </div>
                                            </a>
                                             @endif
                                        @break
                                    @endswitch
                                @endforeach
                            @endif 
                                          
                                           
                                        </div>
                                    </li>
                                    <li>
                                        <a class="nav-link text-center" href="{{ url('/all-notifications') }}"> <strong>Check all notifications</strong> <i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- End Comment -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- Messages -->
                        <!-- ============================================================== -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="" id="2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="mdi mdi-email"></i>
                                <div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
                            </a>
                            <div class="dropdown-menu mailbox animated slideInUp" aria-labelledby="2">
                                @php
                        $chatmessages = chatNotifications();
                    @endphp
                                <ul>
                                    <li>
                                        <div class="drop-title">You have 4 new messages</div>
                                    </li>
                                    <li>
                                        <div class="message-center">
                                             @if( $chatmessages )
                                @foreach( $chatmessages as $chatmessage )
                                    @if( @$chatmessage['user'] )
                                        @php
                                            $profilepic = ( @$chatmessage['user']->profile_pic )? 'uploads/'.$chatmessage['user']->profile_pic : 'images/default.png';
                                        @endphp
                                            <!-- Message -->
                                            <a href="{{ url('/chat') }} " envelope_id="{{ $chatmessage['message']->id }}">
                                                <div class="user-img"> <img src="{{ asset($profilepic) }}" alt="user" class="img-circle"> <span class="profile-status online pull-right"></span> </div>
                                                <div class="mail-contnet">
                                                    <h5>{{ $chatmessage['user']->name }}</h5> <span class="mail-desc">{{ $chatmessage['message']->message }}</span><p>sent a new message</p> <span class="time">{{ \Carbon\Carbon::parse($chatmessage['message']->created_at)->diffForHumans() }}</span> </div>
                                            </a>
                                         @endif
                                @endforeach
                            @endif   
                                           
                                           
                                        </div>
                                    </li>
                                    <li>
                                        <a class="nav-link text-center" href="javascript:void(0);"> <strong>See all e-Mails</strong> <i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- End Messages -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- Messages -->
                        <!-- ============================================================== -->

                        
                        
                             <li class="nav-item dropdown mega-dropdown"> <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="{{ url('/profile/accountsetting') }}"  aria-haspopup="true" aria-expanded="false"><i class="mdi  mdi-settings"></i></a></li>
                        
                       
                         <li class="nav-item dropdown mega-dropdown"> <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="{{ url('myhearts') }}" aria-haspopup="true" aria-expanded="false"><i class="mdi mdi-heart"></i></a></li>
                                                  <li class="nav-item dropdown mega-dropdown"> <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="{{ url('mymatches') }}" aria-haspopup="true" aria-expanded="false"><i class="mdi mdi-heart"></i><i class="mdi mdi-heart"></i></a></li>

                         
                        <!-- ============================================================== -->
                        <!-- End Messages -->
                        <!-- ============================================================== -->
                    </ul>
                    <!-- ============================================================== -->
                    <!-- User profile and search -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav my-lg-0">
                        <!-- ============================================================== -->
                        <!-- Search -->
                        <!-- ============================================================== -->
                        <li class="nav-item hidden-sm-down search-box"> <a class="nav-link hidden-sm-down text-muted waves-effect waves-dark" href="javascript:void(0)"><i class="ti-search"></i></a>
                            <form class="app-search">
                                <input type="text" class="form-control" placeholder="Search & enter"> <a class="srh-btn"><i class="ti-close"></i></a> </form>
                        </li>
                        
                        <!-- ============================================================== -->
                        <!-- Language -->
                        <!-- ============================================================== -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="flag-icon flag-icon-us"></i></a>
                            <div class="dropdown-menu dropdown-menu-right scale-up"> <a class="dropdown-item" href="#"><i class="flag-icon flag-icon-in"></i> India</a> <a class="dropdown-item" href="#"><i class="flag-icon flag-icon-fr"></i> French</a> <a class="dropdown-item" href="#"><i class="flag-icon flag-icon-cn"></i> China</a> <a class="dropdown-item" href="#"><i class="flag-icon flag-icon-de"></i> Dutch</a> </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- Profile -->
                        <!-- ============================================================== -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="{{url('/uploads/'.Auth::user()->profile_pic)}}" alt="user" class="profile-pic" /></a>
                            <div class="dropdown-menu dropdown-menu-right scale-up">
                                <ul class="dropdown-user">
                                    <li>
                                        <div class="dw-user-box">
                                            <div class="u-img"><img src="{{url('/uploads/'.Auth::user()->profile_pic)}}" alt="user"></div>
                                            <div class="u-text">
                                                <h4>{{ Auth::user()->name }}</h4>
                                                <p class="text-muted">varun@gmail.com</p><a href="{{ url('profile') }}" class="btn btn-rounded btn-danger btn-sm">View Profile</a></div>
                                        </div>
                                    </li>
                                    <li role="separator" class="divider"></li>
                                    <li><a href="/profile"><i class="ti-user"></i> My Profile</a></li>
                                    <li><a href="{{ url('payment') }}"><i class="ti-wallet"></i> My Wallet</a></li>
                                    <li><a href="{{url('pricing')}}"><i class="ti-email"></i> Subscription</a></li>
                                    <li role="separator" class="divider"></li>
                                    <li><a href="{{ url('/profile/accountsetting') }}"><i class="ti-settings"></i> Account Setting</a></li>
                                    <li role="separator" class="divider"></li>
                                    <li><a href="{{ route('logout') }}"
									onclick="event.preventDefault();
									document.getElementById('logout-form').submit();"><i class="fa fa-power-off"></i> {{ __('Logout') }}</a><form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
									@csrf
								</form></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>