@extends('v7.frontend')

@section('page_level_styles')
  <style>
  .vegas-background{display:none!important;}
.mid_sec ul li span {
	list-style-type: none;
	border-radius: 50%;
	border: 4px solid #666;
	display: inline-block;
	font-size: 23px;
	height: 58px;
	padding: 8px;
	text-align: center;
	width: 58px;
	color: #666;
	font-weight: bold;
}
 .mid_sec ul li{list-style-type:none;}
  
  
  .mid_sec ul li {
	list-style-type: none;
	width: 32%;
	display: inline-block;
}
.mid_sec {
	text-align: center;
	margin-top: 1rem;
}
.spn1 {
	border-color: #f28238 !important;
	color:#000!important;
}
.center_sec h1, p {
	text-align: center;
	padding-left: 1rem;
}


.lst_sec {
	background: #fff;
}
.pra_dv h1 {
	text-align: center;
	color: #f28238;
	font-size: 23px;
}
  .img_dv img {
        width: 100%;
	max-width: 300px;
         }
         .img_dv {
        text-align: center;
	padding: 30px 0;
         }
.user_sec {
	margin: 30px 0;
}
.input_group {
	text-align: left;
}
.center_sec p{
    margin-bottom:2rem;
  
}
.nxt_btn_sec {
    text-align: right;
}
.nxt_btn_sec a {
    background: #fa781d ;
    color: #fff;
	border-color:#fa781d;
	margin-right:25px;
	padding:5px 25px;
	font-size:20px;
}
.pre_btn_sec {
    text-align: right;
}
.pre_btn_sec a {
    background: #46c6b3 ;
    color: #fff;
	border-color:#46c6b3;
	margin-right:25px;
	padding:5px 25px;
	font-size:20px;
	
}
.footer_sec {
	background: #272727;
	padding:15px 0;
}
.footer_sec ul li {
	font-weight:600;
	color:#fff;
	font-size:20px;
	list-style-type:none;
}
.foot_dv img {
	width: 100%;
	max-width: 100px;
}
.foot_dv p {
	color: #fff;
	text-align: left;
	margin-top: 10px;
	padding-left: 0;
}
.input_group label {
	text-transform: uppercase;
}
.ac_setup {
	background: #fa781d;
	padding: 4px 0;
}


.input_group select {
	font-weight: 600;
	padding: 5px 30px;
}
.ac_setup h1 {
	color: #fff;
	text-align: center;
	font-size: 25px;
	font-weight: 600;
}
.mid_sec p {
	width: 71%;
	text-align: center;
	margin: auto;
	margin-bottom: 28px;
	font-weight: 600;
}

.left_sec {
	background: #fff;
	color: #000;
	padding: 10px;
}
.user_sec.row.top_user {
	margin-top: 50px;
	background: #fff;
	padding-top: 3rem;
}
.spn2::before {
	border-top: 3px solid #666;
	display: block;
	height: 1px;
	content: " ";
	width: 20%;
	position: absolute;
	left: 54%;
	top: 29%;
}
	
	.spn2::after {
	border-top: 3px solid #666;
	display: block;
	height: 1px;
	content: " ";
	width: 20%;
	position: absolute;
	left: 29%;
	top: 29%;
}

.center_sec {
	background: #f1f1f1;
	padding: 30px;
	margin-bottom: 53px;
}




<!-- page 2 css -->

.sme_sec {
	
	text-align: center;
}
.sme_sec {
	text-align: center;
	padding-top: 4rem;
}

.upload_dv p {
	font-size: 21px;
	margin-top: 0.5rem;
	color: #6a6969;
	margin-bottom:0;
}
.upload_dv span {
	font-size: 22px;
	font-weight: 600;
}

.img_dv {
	text-align: center;
}

.upload_dv input {
	color: #fff;
	background: #187ea5;
	text-align: center;
	margin: auto;
}

.row.contct_sec {
	background: #fff;
}
.lvl_sec h1 {
	font-size: 20px;
	font-weight: 600;
	text-align: left;
}

.lvl_sec p {
	text-align: left;
	font-size: 17px;
}
.rvl_sec p {
	text-align: left;
	font-size: 17px;
}
.spn2::before {
	border-top: 3px solid #666;
	display: block;
	height: 1px;
	content: " ";
	width: 20%;
	position: absolute;
	left: 54%;
	top: 51%;
}



.spn2::after {
	border-top: 3px solid #666;
	display: block;
	height: 1px;
	content: " ";
	width: 20%;
	position: absolute;
	left: 26%;
	top: 51%;
}
.rvl_sec {
	/*text-align: center;*/
	/*border: 2px solid #000;*/
	/*padding: 20px;*/
	/*border-radius: 14px;*/
}
.nw_about_sec {
	padding: 30px;
	background: #fff;
	margin: 25px 0;
}
.contct_sec {
	background: #fff;
	margin-bottom: 2rem;
}
.enter_sec ul li {
	background: #f01111;
	width: 23%;
	display: inline-block;
	padding: 4px 20px;
	color: #fff;
	border-radius: 10px;
	margin-right: 5px;
	margin-bottom: 5px;
}


.enter_sec {
	text-align: left;
	border: 2px solid #000;
	padding: 20px;
	border-radius: 14px;
}
       .ac_setup {
	background: #fa781d;
	padding: 4px 0;
	margin-top: 8rem;
}
.star {
	color: #fb0101;
}
  </style>
     @stop
  @section('content')


<div class="ac_setup">
<h1>ACCOUNT SETUP</h1>
</div>


<div class="container">
<div class="mid_sec">
<p>We're happy that you've made it to step 2 with no lag! Finally, we'll get to know you better... </p>
<ul>
<li><span class="">1</span><p> Account Info</p></li>
<li><span class="spn2 spn1">2 </span><p>Profile Info</p></li>
<li><span>3 </span><p>Seeking</p></li>
</ul>


</div>





<div class="center_sec">
<h1>Profile Photo Upload<span class="star">*</span></h1>
<p>Upload your profile picture directly from your device. <br>You may upload even more photos after you complete your account setup. </p>


<div class="contct_sec ">
<div class="row ">


<div class="col-md-6">
<div class=" left_sec  ">
<div class="img_dv">
  <img src="http://placehold.it/800X550" class="width-100" alt="pic">
</div>

</div>
</div>


<div class="col-md-6">
<div class=" left_sec sme_sec  ">

<div class="upload_dv ">
<input class="btn" type='file' onchange="readURL(this);" />
<br><span><font color="red">No Text | No Nudity | No 1st Life</font></span>
</div>
<p><i>Do not upload photos containing texts, nudity, nor 1st Life. Doing so will result in delayed registration, account restriction or termination. <br>For more information, please see our Terms and Policy</i></p>

</div>
</div>
</div>




</div>



<div class="nw_about_sec">

<div class="row ">
<div class="col-md-4">
<div class="lvl_sec">
<h1>About <span class="star">*</span></h1>
<p><i>This is all about you! Besides, only you can tell your story the way it should be told; so make this one count ;)</i></p>

</div>
</div>




<div class="col-md-8">
<div class="rvl_sec">
<textarea rows="4" cols="50">

</textarea>

</div>
</div>
</div>
</div>


<div class="nw_about_sec">

<div class="row ">
<div class="col-md-4">
<div class="lvl_sec">
<h1>My Fun ( Tag Along ) <span class="star">*</span></h1>
<p><i>Add relevant tags of things that you find exciting and indulge in regularly.</i></p>

</div>
</div>




<div class="col-md-8">
<div class="enter_sec">

<ul>
<li>gaming</li>
<li>reading</li>
<li>shoping</li>
<li>watching tv</li>
<li>eating </li>
<li>gaming </li>
</ul>

</div>
</div>
</div>
</div>

<div align="right">
<align><span class="pre_btn_sec">
<a href="{{route('account-setup')}}" class="btn btn-primary">PREVIOUS</a>
</span>

<span class="nxt_btn_sec">
<a href="" class="btn btn-primary">NEXT</a>
</span>
</align>
</div>

</div>
</div>

  @endsection 
    
