@extends('v7.frontend')

@section('page_level_styles')
      <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">-->
      <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>-->
      <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>-->
      <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>-->
      <style>
      .vegas-background{display:none!important;}
         .mid_sec ul li span {
         list-style-type: none;
         border-radius: 50%;
         border: 4px solid #666;
         
         display: inline-block;
         font-size: 23px;
         height: 58px;
         padding: 8px;
         text-align: center; 
         width: 58px;
         color: #666;
         font-weight: bold;
         }
         .ac_setup {
	background: #fa781d;
	padding: 4px 0;
	margin-top: 8rem;
}


         .mid_sec ul li{list-style-type:none;}
         .mid_sec ul li {
         list-style-type: none;
         width: 32%;
         display: inline-block;
         }
         .mid_sec {
         text-align: center;
         margin-top: 1rem;
         }
         .spn1 {
         border-color: #f28238 !important;
         color:#000!important;
         }
         .center_sec h1, p {
         text-align: center;
         padding-left: 1rem;
         }

         .pra_dv h1 {
         text-align: center;
         color: #3e3936;
         font-size: 23px;
         }
         .img_dv img {
        width: 100%;
	max-width: 192px;
         }
         .img_dv {
        text-align: center;
	padding: 30px 0;
         }
       .user_sec {
    border-bottom: 1px solid #e8e8ea;
    background: #fff;
    padding: 30px;
       /*margin: 30px 0;*/
       /* margin-top: 30px;*/
    border-bottom: 1px solid #e8e8ea;
}


.top_user {
	margin: 30px 0;
}

         .input_group {
         text-align: left;
         }
         .center_sec p{
         margin-bottom:2rem;
         }
         .nxt_btn_sec {
         text-align: right;
         }
         .nxt_btn_sec a {
         background: #fa781d ;
         color: #fff;
         border-color:#fa781d;
         margin-right:25px;
         padding:5px 25px;
         font-size:20px;
         }
         .footer_sec {
         background: #272727;
         padding:15px 0;
         }
         .footer_sec ul li {
         font-weight:600;
         color:#fff;
         font-size:20px;
         list-style-type:none;
         }
         .foot_dv img {
         width: 100%;
         max-width: 100px;
         }
         .foot_dv p {
         color: #fff;
         text-align: left;
         margin-top: 10px;
         padding-left: 0;
         }
         h3.user_text {
    text-align: center;
    line-height: 0px;
        font-size: 30px;
}
        .input_group label {
    /*text-transform: uppercase;*/
    color: #000!important;
    font-size:16px;
}
          .ac_setup {
	background: #fa781d;
	padding: 4px 0;
	margin-top: 8rem;
}
         .input_group select {
         font-weight: 600;
         padding: 5px 30px;
         }
         .ac_setup h1 {
         color: #fff;
         text-align: center;
         font-size: 25px;
         font-weight: 600;
         }
         .mid_sec p {
         width: 71%;
         text-align: center;
         margin: auto;
         margin-bottom: 28px;
         font-weight: 600;
         }
  
         .left_sec {
         background: #fff;
         color: #000;
         padding: 10px;
         }
         .user_sec.row.top_user {
         margin-top: 50px;
         background: #fff;
         padding-top: 3rem;
         }
         .spn2::before {
         border-top: 3px solid #666;
         display: block;
         height: 1px;
         content: " ";
         width: 20%;
         position: absolute;
         left: 54%;
         top: 52%;
         }
         .spn2::after {
         border-top: 3px solid #666;
         display: block;
         height: 1px;
         content: " ";
         width: 20%;
         position: absolute;
         left: 25%;
         top: 52%;
         }
         .center_sec {
         background: #f1f1f1;
         padding: 30px;
         margin-bottom: 53px;
         }
         <!-- page 2 css -->
         .sme_sec {
         text-align: center;
         }
         .sme_sec {
         text-align: center;
         padding-top: 4rem;
         }
         .upload_dv p {
         font-size: 21px;
         margin-top: 0.5rem;
         color: #6a6969;
         margin-bottom:0;
         }
         .upload_dv span {
         font-size: 22px;
         font-weight: 600;
         }
         .img_dv {
         text-align: center;
             padding: 2rem;
         }
         .upload_dv input {
         color: #fff;
         background: #187ea5;
         }
         .row.contct_sec {
         background: #fff;
         }
         .lvl_sec h1 {
         font-size: 20px;
         font-weight: 600;
         text-align: left;
         }
         .lvl_sec p {
         text-align: left;
         font-size: 17px;
         }
         rvl_sec p {
         text-align: left;
         font-size: 17px;
         }
         .rvl_sec {
         text-align: center;
         border: 2px solid #000;
         padding: 20px;
         border-radius: 14px;
         }
         .nw_about_sec {
         padding: 30px;
         background: #fff;
         margin: 25px 0;
         }
         .contct_sec {
         background: #fff;
         margin-bottom: 2rem;
         }
         .enter_sec ul li {
         background: #f01111;
         width: 23%;
         display: inline-block;
         padding: 4px 20px;
         color: #fff;
         border-radius: 10px;
         margin-right: 5px;
         margin-bottom: 5px;
         }
         .enter_sec {
         text-align: left;
         border: 2px solid #000;
         padding: 20px;
         border-radius: 14px;
         }
         .nxt_btn_sec {
	text-align: right;
	margin-right: 8rem;
	margin-bottom: 2rem;
	margin-top: 0;
}
.lst_sec {
	margin-top: 3rem;
}
.hr-text {
  line-height: 1em;
  position: relative;
  outline: 0;
  border: 0;
  color: black;
  text-align: center;
  height: 1.5em;
  opacity: .5;

}
hr.hr_sec {
    border-top: 1px solid #8a8a8a;
}
         @media (max-width: 767px) {
.spn2::before,.spn2::after{display:none;}

}
.star {
	color: #fb0101;
}
.input_group select {
    width: 50%;
}
.switch {
	position: relative;
	display: inline-block;
	width: 42px;
	height: 19px;
}
.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}
.switch_sec{
    text-align:center;
}
.slider {
	position: absolute;
	cursor: pointer;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background-color: #fd0000;
	-webkit-transition: .4s;
	transition: .4s;
}

.slider::before {
	position: absolute;
	content: "";
	height: 10px;
	width: 11px;
	left: 4px;
	bottom: 4px;
	background-color: white;
	-webkit-transition: .4s;
	transition: .4s;
}
input:checked + .slider {
	background-color: #21F33D;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}
.cl_ble #usr {
	text-align: center;
	background: #e5e9f0 !important;
	border-radius: 15px;
	color: #fff !important;
	font-weight: bold;
	font-size: 17px;
	border: none;
}
.label.lbl {
	line-height: 28px;
}
.ur_sec {
	margin: 2rem 0;
}
.ur_sec p {
	font-size:15px;
	font-style:italic;
}
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
.input_group.cl_ble a {
	padding: 5px 30px;
	border-radius: 30px;
	border: none;
}
.para_g {
	margin-top: 2rem;
}
.para_g p {
	font-size: 16px;
}
.para_g span {
	font-weight: bold;
	padding: 0 5px;
	color: #47c6b3;
}
      </style>
      @stop
  @section('content')
      <div class="ac_setup">
         <h1>ACCOUNT SETUP</h1>
      </div>
      <div class="container">
         <div class="mid_sec">
            <p>Thanks for joining Avdopt; now, lets setup your account in 3 easy steps. Each step is mandatory and information provided will be used solely to <b>match</b> you with the right avatars effectively. <br>  </p>
            <ul>
               <li>
                  <span class="spn1">1</span>
                  <p><b>Account Info</b></p>
               </li>
               <li>
                  <span class="spn2">2 </span>
                  <p>Profile Info</p>
               </li>
               <li>
                  <span>3 </span>
                  <p>Seeking</p>
               </li>
            </ul>
         </div>
         <div class="center_sec">
             <div class="row">
                
                 <div class="col-md-5">
                 <hr class=hr_sec>
                 </div>
                  <div class="col-md-2 user_text">
                <h3 class="user_text">User Group</h3>
                 </div>
                  <div class="col-md-5">
                 <hr class=hr_sec>
                 </div>
                 </div>
            

            <p>Please choose a User Group by activating it below. Your user group is your identity on Avdopt; <br>however, you may change your user group as many times as you like. Learn More </p>
            <div class="row">
               <div class="col-md-2 col-md-offset-1">
                  <div class=" left_sec  ">
                     <div class="img_dv">
                      <img src="http://laravel.avdopt.com/frontend/images/usergroup/toddler.jpg" class="width-100" alt="pic">
                     </div>
                     <div class="pra_dv">
                        <h1>Toddler</h1>
                        <div class="switch_sec"> 
                        <label class="switch">
                        <input type="checkbox" unchecked>
                        <span class="slider round"></span>
                        </label>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-2 ">
                  <div class="left_sec  ">
                     <div class="img_dv">
                        <img src="http://laravel.avdopt.com/frontend/images/usergroup/child.jpg" class="width-100" alt="pic">
                     </div>
                     <div class="pra_dv">
                        <h1>Child</h1>
                        <div class="switch_sec"> 
                        <label class="switch">
                        <input type="checkbox" unchecked>
                        <span class="slider round"></span>
                        </label>
                        </div>
               
                     </div>
                  </div>
               </div>
                <div class="col-md-2 ">
                  <div class="left_sec  ">
                     <div class="img_dv">
                        <img src="http://laravel.avdopt.com/frontend/images/usergroup/ugteen.jpg" class="width-100" alt="pic">
                     </div>
                     <div class="pra_dv">
                        <h1>Teen</h1>
                        <div class="switch_sec"> 
                        <label class="switch">
                        <input type="checkbox" unchecked>
                        <span class="slider round"></span>
                        </label>
                        </div>
                     </div>
                  </div>
               </div>
                <div class="col-md-2 ">
                  <div class=" left_sec  ">
                     <div class="img_dv">
                        <img src="http://laravel.avdopt.com/frontend/images/usergroup/adult.jpg" class="width-100" alt="pic">
                     </div>
                     <div class="pra_dv">
                        <h1>Adult</h1>
                     <div class="switch_sec"> 
                        <label class="switch">
                        <input type="checkbox" unchecked>
                        <span class="slider round"></span>
                        </label>
                        </div>
                     </div>
                  </div>
               </div>
               
               
                     <div class="col-md-2 ">
                  <div class=" left_sec  ">
                     <div class="img_dv">
                        <img src="http://laravel.avdopt.com/frontend/images/usergroup/elder.jpg" class="width-100" alt="pic">
                     </div>
                     <div class="pra_dv">
                        <h1>Elder</h1>
                     <div class="switch_sec"> 
                        <label class="switch">
                        <input type="checkbox" unchecked>
                        <span class="slider round"></span>
                        </label>
                        </div>
                     </div>
                  </div>
               </div>
               
               <div class="row ">
                <div class="col-md-12 ">
                    <div class="para_g">
                     <p>You've successfully activated your <b>User Group</b>, and you're now a<span>Toddler</span>.</p> 
                        
                    </div>
                    </div>
                    </div>
                    
               
               
            </div>
            
            <div class="lst_sec">
              
               <div class="user_sec ">
                   <div class=" row">
                  <div class="col-md-4">
                     <div class="input_group">
                        <label class="label lbl">Gender: <span class="star">*</span></label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="input_group">
                        <select>
                           <option value="boy" selected >Boy</option>
                           <option value="girl">Girl</option>
                           
                        </select>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="input_group">
                        <p><i>Please choose your Gender</i></p>
                     </div>
                  </div>
               </div>
               </div>
               
               <div class="user_sec ">
                    <div class=" row">
                  <div class="col-md-4">
                     <div class="input_group">
                        <label class="label lbl">Age: <span class="star">*</span></label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="input_group">
                        <select>
                           <option value="boy" selected >9</option>
                           <option value="girl">11</option>
                           <option value="girl">15</option>
                           
                        </select>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="input_group">
                        <p><i>Choose the age that you roleplay;<br>not your Real Life age silly ;)</i></p>
                     </div>
                  </div>
               </div>
                </div>
                
                
                
           
                
                
                
                    <div class="user_sec ">
                    <div class=" row">
                  <div class="col-md-3">
                     <div class="input_group">
                        <label class="label lbl" style="color:#5197f6">Family role:<span class="star">*</span> </label>
                     </div>
                  </div>
                  <div class="col-md-3">
                     <div class="input_group cl_ble">
                       
                          <a href="" class="btn btn-primary">son</a>
                     </div>
                  </div>
                  <div class="col-md-3">
                     <div class="input_group cl_ble">
                       
                          <a href="" class="btn btn-primary">brother</a>
                     </div>
                  </div>
                  
                  <div class="col-md-3">
                     <div class="input_group cl_ble">
                       
                          <a href="" class="btn btn-primary">Grandson</a>
                     </div>
                  </div>
                  <div class="col-md-12">
                      <div class="ur_sec ">
                      <p>Please choose the <b>Family Roles</b> that represents you best. Family Roles influences <br>your relevance in searches and the entire adoption process. Although you may choose<br> multiple Family Roles, it is within your best interest to choose wisely. Learn More</p>  
                    </div>
                    </div>
                 
                 
                 
               </div>
                </div>
                
                
                           <div class="user_sec ">
                    <div class=" row">
                  <div class="col-md-4">
                     <div class="input_group">
                        <label class="label lbl">Species <span class="star">*</span></label>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div class="input_group">
                        <select>
                           <option value="boy" selected >human</option>
                           <option value="girl">human</option>
                           <option value="girl">human</option>
                           
                        </select>
                     </div>
                  </div>
                   <div class="col-md-4">
                     <div class="input_group">
                        <p><i>Just follow your heart...</i></p>
                     </div>
                  </div>
                  
               
                </div>
                
                
                </div>
                
             
               
 
            </div>
            </div>
            <div class="nxt_btn_sec">
              
               <a href="{{route('account-setupnext')}}" class="btn btn-primary">NEXT</a>
            </div>
         </div>
      </div>
   
    @endsection 
    
   