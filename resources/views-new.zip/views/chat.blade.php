@extends('layouts.admin')
@section('htmlheader')
     <script src="{{ asset('js/app.js') }}" defer></script>
@endsection
@section('main-content')
<div class="maincontent">
	<div class="content bgwhite">
        <div class="chat">
        	<div class="container-fluid">
        		<h4 class="font22 inline_block"><b class="vertical_align"><img src="{{ asset('backend/images/chat2.png') }}" alt="Report" title="Img">CHAT</b></h4>
        			<hr>
                    @if($message)
                        <div class="alert alert-info">{{ @$message }}</div>
                    @endif
        	   
        		@if ( isthisSubscribed() || getmanualfeatures('token_monthly_connection_'))
        		   	<div class="mtop30">
            		    <chat-users v-on:fetchusers="fetchMessages" :chatnewusers="chatnewusers" :chatusers="chatusers"></chat-users>
            			<chat-messages v-on:messagesent="addMessage" v-on:fetchusers="fetchMessages" :user="{{ Auth::user() }}" :messages="messages"></chat-messages>
            		</div>
                @else
        	        @include('includes.debitTokens', ['featurevalue'=>'token_monthly_connection_value_','featureclass'=>'chat','featurename'=>'token_monthly_connection_', 'featureMessage'=>'Hey '. ucfirst( Auth::user()->name ) .'!. Upgrade your membership today to experience unlimited chat.'])
        	    @endif
        	</div>	
        </div>
    </div>
    <div class="chat_notify" id="notifyerror"><i class="fa fa-warning"></i> <span>Notification</span></div>
</div>
@endsection