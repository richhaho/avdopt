@extends('layouts.master')
@section('htmlheader')
    <link rel="stylesheet" href="{{ asset('css/stripe.css') }}" type="text/css" />
    <script src="https://js.stripe.com/v3/"></script>
@endsection
@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">  
        <div class="membership">
			<div class="container-fluid">
                <form action="{{ route('payment.charge') }}" method="POST" id="payment-form">
                    @csrf
                    <div class="form-row">
                        <input type="hidden" name="stripeToken" id="stripeToken" />
                        <label for="card-element">
                            Token
                        </label>
                        <input type="number" class="form-control" name="amount" value="0" id="amount" />
                    </div>
                    <div class="form-row">
                        <label for="card-element">
                            Enter Card Details
                        </label>
                        <div id="card-element">
                            <!-- A Stripe Element will be inserted here. -->
                        </div>
        
                        <!-- Used to display form errors. -->
                        <div id="card-errors" role="alert"></div>
                    </div>
        
                    <button class="btn btnred pull-right">Submit Payment</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection    
@section('footer')
<script type="text/javascript" src="{{ asset('js/stripe.js') }}"></script>
@endsection        