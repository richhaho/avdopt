@extends('v7.frontend')
@section('page_level_styles')
<style>
    .save_event{
        cursor: pointer;
    } 
    .save_event.saved{ 
        background-color:green;
    }
    .img_sec {
        height: 203px;
    }
</style>

<!--<link href="http://fonts.googleapis.com/css?family=Lato:400,900,700,400italic,300,700italic" rel="stylesheet" type="text/css">-->
<!--<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400italic,700' rel='stylesheet' type='text/css'>    -->
   
<!--<link rel="stylesheet" type="text/css" href="{{ asset('frontendevents/assets/css/bootstrap.min.css')}}">-->
<!--<link rel="stylesheet" type="text/css" href="{{ asset('frontendevents/assets/css/font-awesome.min.css')}}">-->
<!--<link rel="stylesheet" type="text/css" href="{{ asset('frontendevents/assets/css/flexslider.css')}}">-->
<!--<link rel="stylesheet" type="text/css" href="{{ asset('frontendevents/assets/css/owl.carousel.css')}}">-->
<!--<link rel="stylesheet" type="text/css" href="{{ asset('frontendevents/assets/css/animations.css')}}">-->
<!--<link rel="stylesheet" type="text/css" href="{{ asset('frontendevents/assets/css/dl-menu.css')}}">-->
<!--<link rel="stylesheet" type="text/css" href="{{ asset('frontendevents/assets/css/jquery.datetimepicker.css')}}">-->
<link rel="stylesheet" href="{{ asset('frontendevents/assets/css/main.css')}}">
  
@stop
@section('content')
 <!-- Start Events Section -->

<div class="majorWrap">

  

    <!--=================================================
    events finder
    ==================================================-->

        <section class="events-finder" style="margin-top:10rem;">
            <div class="container">
                <header><meta http-equiv="Content-Type" content="text/html; charset=big5">
                      <form action="" method="GET">
              @csrf
                    <div class="row">
                        <div class="col-xs-12 col-md-3">
                            <h2 class="text-uppercase">Latest Events.</h2>
                        </div>
                        <div class="col-xs-12 col-md-9">                            
                            <div class="event-form text-right">
                                <form>
                                    <div class="form-input search-keyword">
                                        <input type="text" placeholder="Search Keyword">
                                        <i class="icon fa fa-search"></i>
                                    </div>
                                    
                                      <div class="form-input select-location">
                                        <div class="custome-select">
                                            <b class="icon fa fa-calendar"></b>
                                            <span>Select a date</span>
                                    @php
                                    $months = array(1 => 'Jan.', 2 => 'Feb.', 3 => 'Mar.', 4 => 'Apr.', 5 => 'May', 6 => 'Jun.', 7 => 'Jul.', 8 => 'Aug.', 9 => 'Sep.', 10 => 'Oct.', 11 => 'Nov.', 12 => 'Dec.');
                                    @endphp
                                    <select name="dates" id="search-dropdown-box" class="search-cate notranslate">
                                    <option value="-1">All Dates</option>
                                    @foreach($months as $key=>$month)
                                    <option @if(isset($_GET['dates'])) @if($key == $_GET['dates'] ) selected @endif @endif value="{{ $key }}">{{ $month }}</option>
                                    @endforeach
                                    </select>
                                     </div> 
                                    </div>
                                    
                                    
                                    <div class="form-input select-location">
                                        <div class="custome-select">
                                            <b class="fa fa-bars"></b>
                                            <span>Select a Category</span>
                                            
                            <select name="category" id="search-dropdown-box" class="search-cate notranslate">
                            @foreach($categories as $category)
                            <option @if(isset($_GET['category'])) @if($category->id == $_GET['category'] ) selected @endif @endif value="{{ $category->id }}">{{ $category->term_name }}</option>
                            @endforeach
                            </select>
                                            <!--<select id="search-dropdown-box" class="search-cate notranslate">-->
                                            <!--   <option value="">Option1</option>                      -->
                                            <!--   <option value="">Option2</option>                      -->
                                            <!--   <option value="">Option3</option>                      -->
                                            <!--   <option value="">Option4</option>                      -->
                                            <!--   <option value="">Option5</option>                      -->
                                            <!--</select>-->
                                        </div> 
                                    </div>
                                    <button class="btn btn-default" type="submit">find event</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    </form>
                </header>
                <div class="featured-events">
                    <div class="row">
                    <div class="col-xs-12">
                        <div class="store-grid text-uppercase text-bold">
                             @if (count($events) > 0)
                  @foreach($events as $event)
                    @php
                   
                      $to = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $event->date);
                      $day = date('D', strtotime($to));
                      $dayNumceric = date('d', strtotime($to)); 
                      $month = date('M', strtotime($to)); 
                      $time = date('h:i A', strtotime($event->date));
                    @endphp
                            <div class="store-product">
                                <figure>
                                    
                                    @if(!empty($event->image))
                                    <img class="img_sec" width="265" height="265" src="{{ asset('/images/events/'.$event->image)}}">
                                    @else
                                    <img class="img_sec" width="265" height="265" src="{{ asset('frontendevents/assets/demo-data/a1.jpg')}}">
                                    @endif
                                    <figcaption>
                                        <a href="{{ route( 'event.single', $event->id ) }}" class="btn btn-grey" target="_blank"><i class="fa fa-ticket "></i> View</a>
                                    </figcaption>
                                </figure>
                                <div class="product-info">
                                    <h3>{{ @$event->title }}</h3>
                                    <h6><i class="fa fa-clock-o"></i> {{ $day }}, {{ $month }} {{ $dayNumceric }}</h6>
                                    <span class="price-tag">${{$event->price * 100}}</span>
                                </div>
                                
                            </div>
                         @endforeach 
                            @else
                            <h3 class="text-center">No Results Found</h3>
                            @endif
                        </div><!--album-grid-->
                        
                    </div><!--column-->     
                </div>
                </div>
            </div>
        </section>

   
   
      
    </div>
   
        
    </div>

        <!-- End profile Edit Section -->


@endsection
@section('scripts')
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script>
    var csrf_token ='{{ csrf_token() }}';
</script>
<script src="{{ asset('frontend/js/events.js') }}" type="text/javascript" language="JavaScript"></script>

<script src="{{ asset('frontendevents/assets/js/modernizr-2.6.2-respond-1.1.0.min.js')}}"></script>
<script src="{{ asset('frontendevents/assets/js/jquery.js')}}"></script>
<!--<script src="{{ asset('frontendevents/assets/js/ajaxify.min.js')}}"></script>-->
<script src="{{ asset('frontendevents/assets/js/jquery.downCount.js')}}"></script>
<script src="{{ asset('frontendevents/assets/js/jquery.datetimepicker.full.min.js')}}"></script>
<script src="{{ asset('frontendevents/assets/js/jquery.bxslider.min.js')}}"></script>
 <script src='https://maps.googleapis.com/maps/api/js?v=3.exp&#038;sensor=false&#038;ver=3.0'></script>
<script src="{{ asset('frontendevents/assets/js/jplayer/jquery.jplayer.min.js')}}"></script>
<script src="{{ asset('frontendevents/assets/js/jplayer/jplayer.playlist.min.js')}}"></script>
<script src="{{ asset('frontendevents/assets/js/jquery.flexslider-min.js')}}"></script>
<script src="{{ asset('frontendevents/assets/js/jquery.stellar.min.js')}}"></script>
<script src="{{ asset('frontendevents/assets/js/jquery.sticky.js')}}"></script>
<script src="{{ asset('frontendevents/assets/js/jquery.waitforimages.js')}}"></script>
<script src="{{ asset('frontendevents/assets/js/masonry.pkgd.min.js')}}"></script>
<script src="{{ asset('frontendevents/assets/js/packery.pkgd.min.js')}}"></script>
<script src="{{ asset('frontendevents/assets/js/tweetie.min.js')}}"></script>
<script src="{{ asset('frontendevents/assets/js/owl.carousel.min.js')}}"></script>

<script src="{{ asset('frontendevents/assets/js/main.js')}}"></script>  
    $(document).ready(function() {
        $('.searchdropdown').select2({
            placeholder: 'Search events or catagories',
        });
    });
</script>
<style>
span.select2-container ul li, span.select2-container span {
    width: 100%;
}
.select2-container--default .select2-selection--single {
    height: 42px;
    border-radius: 0;
}
.select2-container--default .select2-selection--single .select2-selection__arrow {
    height: 37px;
  }
  .select2-container--default .select2-selection--single .select2-selection__rendered {
    line-height: 41px;
}
</style>
@endsection