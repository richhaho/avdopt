@extends('layouts.master')
@section('htmlheader')
<link href="http://demo.expertphp.in/css/dropzone.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/owl.carousel.min.css') }}">
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
<script src="http://demo.expertphp.in/js/dropzone.js"></script>
<script src="{{ asset('backend/js/profile.js') }}" type="text/javascript"></script>
@endsection
@section('main-content')
<div class="maincontent backend">

<div class="content"> 
<div class="profile_edit">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <div class="container-fluid">
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-body">
                                <center class="m-t-30"> <img src="{{url('/uploads/'.Auth::user()->profile_pic)}}" class="img-circle" width="150" />
                                    <h4 class="card-title m-t-10">{{ Auth::user()->name }}</h4>
                                   <!-- <h6 class="card-subtitle">Accoubts Manager Amix corp</h6>-->
                                    <div class="row text-center justify-content-md-center">
                                        <!--<div class="col-4"><a href="javascript:void(0)" class="link"><i class="icon-people"></i> <font class="font-medium">254</font></a></div>
                                        <div class="col-4"><a href="javascript:void(0)" class="link"><i class="icon-picture"></i> <font class="font-medium">54</font></a></div>-->
                                    </div>
                                </center>
                            </div>
                            <div>
                                <hr> </div>
                            <div class="card-body"> <small class="text-muted">Email address </small>
                                <h6>{{ $user->email }}</h6> <small class="text-muted p-t-30 db">Phone</small>
                                <h6>+91 654 784 547</h6> <small class="text-muted p-t-30 db">Address</small>
                                <h6>71 Pilgrim Avenue Chevy Chase, MD 20815</h6>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs profile-tab" role="tablist">
                                
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#settings" role="tab">Account Settings</a> </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                
                                <!--second tab-->
                                
                                <div class="tab-pane active" id="home" role="tabpanel">
                                    <div class="card-body">
                                        @if(session()->has('message'))
                                <div class="alert alert-success">
                                    {{ session()->get('message') }}
                                </div>
                                    @endif
                                    <form class="form-horizontal form-material" action="{{route('updateaccount.setting', $user->id )}}" method="post">
                                        @csrf
                                            <div class="form-group">
                                                <label class="col-md-12">Email</label>
                                                <div class="col-md-12">
                                                    <input type="email" name="email" value="{{ $user->email }}" class="form-control form-control-line">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="example-email" class="col-md-12">New Password</label>
                                                <div class="col-md-12">
                                                    <input type="Checkbox" id="generatepassword" class="form-control form-control-line" > New Password
                                                    <div id="inputpassword"></div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-12">Notifications</label>
                                                <div class="col-md-12">
                                                    <section class="slider-checkbox">
                                                <input type="checkbox" id="1" value="1" name="notification" @if($user->is_notifications_enable==1) checked @endif/>
                                                <label class="label" for="1">Checkbox 1</label>
                                             </section>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-12">Make Profile Private</label>
                                                <div class="col-md-12">
                                                    <!--<input type="text" placeholder="123 456 7890" class="form-control form-control-line">-->
                                                    <section class="slider-checkbox">
                                                        <input type="checkbox" value="1" id="2" name="privacy"  @if($user->is_private==1) checked @endif/>
                                                        <label class="label" for="2">Checkbox 1</label>
                                                    </section>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-12">Delete Account</label>
                                                <div class="col-md-12">
                                                    <a href="{{ route('profile.permanentdelete') }}" onClick="return confirm('Are your sure you want to delete your account');" class="bgred border_radius btn btn-danger" > <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Delete your Account Permanently</a>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-12">
                                                    <button type="text" placeholder=""  class="btn btn-success pull-right">Update Profile</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
            </div>
        </div>
    </div>
</div>
</div>  
</div>
</div>
@endsection
@section('footer')
<script type="text/javascript">

$(document).ready(function(){
    $("#generatepassword").click(function(){
        if($(this).is(':checked'))
            $('#inputpassword').append('<input placeholder="Enter Your New Password" type="password" name="password" value="" class="border_radius">');
        else
           $('#inputpassword').empty();
    });  
});
</script>
<style type="text/css">

.slider-checkbox {
  position: relative;
      width: 170px;
          right: 30px;
}
.slider-checkbox input {
    margin: 0px;
    margin-top: 1px;
    cursor: pointer;
    opacity: 0;
    -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
    filter: alpha(opacity=0);
    -moz-opacity: 0;
    -khtml-opacity: 0;
    opacity: 0;
    position: absolute;
    z-index: 1;
    top: 0px;
    left: 0px;
    background: red;
    width: 40px;
    height: 20px;
}
.slider-checkbox input:checked + .label:before {
        background-color: red;
        content: "\f00c";
        padding-left: 6px;
}
.slider-checkbox input:checked + .label:after {
        left: 31px;
}
.slider-checkbox .label {
    position: relative;
    padding-left: 46px;
    text-align:left;
}
.slider-checkbox .label:before, .slider-checkbox .label:after {
      position: absolute;
      -webkit-border-radius: 10px;
      -moz-border-radius: 10px;
      border-radius: 10px;
      transition: background-color 0.3s, left 0.3s;
    }
.slider-checkbox .label:before {
      content: "\f00d";
      color: #fff;
      box-sizing: border-box;
      font-family: 'FontAwesome', sans-serif;
      padding-left: 23px;
      font-size: 12px;
      line-height: 20px;
      background-color: grey;
      left: 0px;
      top: 0px;
      height: 20px;
      width: 50px;
      -webkit-border-radius: 10px;
      -moz-border-radius: 10px;
      border-radius: 10px;
    }
.slider-checkbox .label:after {
      content: "";
      letter-spacing: 20px;
      background: #fff;
      left: 1px;
      top: 1px;
      height: 18px;
      width: 18px;
    }

</style>
@endsection