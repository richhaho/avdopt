@extends('layouts.master')
@section('htmlheader')
<link rel="stylesheet" type="text/css" href="{{ asset('css/slick.css') }}"/><link rel="stylesheet" type="text/css" href="http://kenwheeler.github.io/slick/slick/slick-theme.css"/>
<script type="text/javascript" src="{{ asset('js/slick.js') }}"></script>
@endsection
@section('main-content')
  <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">Profile</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                       
                        <li class="breadcrumb-item active">Profile</li>
                    </ol>
                </div>
                <div>
                    <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button>
                </div>
            </div>

    <div class="container-fluid">

        @if ( !isthisSubscribed() )
	        <div class="row upgrade">
    			<div class="col-md-10">
    				<div class="upgdinfo bggray font300">
    					<p>Hey {{ ucfirst( Auth::user()->name ) }}! Upgrade your membership today to experience unlimited features.</p>
    				</div>
    			</div>
    			<div class="col-md-2">							
        			<a style="padding: 18px 0px;" href="{{ url('pricing') }}" class="btn btnred width100">Upgrade Membership</a>
    			</div>
    		</div>
	    @endif

                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-body">
                                <center class="m-t-30"> <img src="{{ ( $user->profile_pic )? url('/uploads').'/'.$user->profile_pic : url('/images/default.png')}}" class="img-circle" width="150" />
                                    <h4 class="card-title m-t-10">{{ ucfirst( $user->name ) }}</h4>
                                    <h6 class="card-subtitle">Accoubts Manager Amix corp</h6>
                                    <div class="row text-center justify-content-md-center">
                                        <div class="col-4"><a href="javascript:void(0)" class="link"><i class="icon-people"></i> <font class="font-medium">254</font></a></div>
                                        <div class="col-4"><a href="javascript:void(0)" class="link"><i class="icon-picture"></i> <font class="font-medium">54</font></a></div>
                                    </div>
                                </center>
                            </div>
                            <div>
                                <hr> </div>
                            <div class="card-body"> <small class="text-muted">Email address </small>
                                <h6>{{ ucfirst( $user->email ) }}</h6> <small class="text-muted p-t-30 db">Joining Date</small>
                                <h6>{{ ( $user->created_at )? date("F j, Y, g:i A", strtotime($user->created_at) ) : '' }}</h6> <small class="text-muted p-t-30 db">Address</small>
                                <h6>71 Pilgrim Avenue Chevy Chase, MD 20815</h6>

                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs profile-tab" role="tablist">
                                <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#home" role="tab">Gallery</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Profile</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#settings" role="tab">Questionnaire</a> </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="home" role="tabpanel">
                                    <div class="card-body">
                                        <div class="profiletimeline">
                                            <div class="sl-item">
                                                <div class="sl-left"> <img src="{{ ( $user->profile_pic )? url('/uploads').'/'.$user->profile_pic : url('/images/default.png')}}" alt="user" class="img-circle" /> </div>
                                                <div class="sl-right">
                                                    <div><a href="#" class="link">{{ ucfirst( $user->name ) }}</a>
                                                        <p>Gallery by <a href="#"> {{ ucfirst( $user->name ) }} </a></p>
                                                        <div class="row">
                                                            @php
                                                                $images = $user->photos;
                                                            @endphp
                                                            @if( $images )
                                                                @foreach($images as $row)
                                                                    <div class="col-lg-6 col-md-6 m-b-20" ><img  src="{{ asset('/uploads/'.$row->image)}}" class="img-responsive radius" alt="Profile Img" title="Profile Img"> </div>
                                                                @endforeach
                                                            @endif
                                                            <!--<div class="col-lg-3 col-md-6 m-b-20"><img src="../assets/images/big/img1.jpg" class="img-responsive radius" /></div>-->
                                                        </div>
                                                        <div class="like-comm"> <a href="javascript:void(0)" class="link m-r-10">2 comment</a> <a href="javascript:void(0)" class="link m-r-10"><i class="fa fa-heart text-danger"></i> 5 Love</a> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                <!--second tab-->
                                <div class="tab-pane" id="profile" role="tabpanel">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-3 col-xs-6 b-r"> <strong>Full Name</strong>
                                                <br>
                                                <p class="text-muted">{{ ucfirst( $user->name ) }}</p>
                                            </div>
                                            <div class="col-md-3 col-xs-6 b-r"> <strong>Membership Type</strong>
                                                <br>
                                                <p class="text-muted">{!! getGroupTagWithColor($user->id) !!}</p>
                                            </div>
                                            <div class="col-md-3 col-xs-6 b-r"> <strong>Age</strong>
                                                <br>
                                                <p class="text-muted">{{ ( $user->age )? $user->age . ' Years' : '' }}</p>
                                            </div>
                                            <div class="col-md-3 col-xs-6"> <strong>Gender</strong>
                                                <br>
                                                <p class="text-muted">{{ @$user->usergender->title }}</p>
                                            </div>
                                        </div>
                                        
                                        <div class="card-body"> <small class="text-muted">Species</small>
                                            <h6>{{ $user->species?$user->species->name:'N/A' }}</h6> <small class="text-muted p-t-30 db">Join Date</small>
                                            <h6>{{ ( $user->created_at )? date("F j, Y, g:i A", strtotime($user->created_at) ) : '' }}</h6> <small class="text-muted p-t-30 db">Last Seen</small>
                                            <h6>{!! $user->last_seen_ago_html !!}</h6>
                                        </div>
                                        <div class="card-body"> <small class="text-muted">Species</small>
                                            <h6>{{ $user->about_me}}</h6>
                                        </div>
                                        
                                        
                                        <div class="row mtop30">
                                            <div class="col-md-8 padding0">
                                                <button type="button" class="like_btn "><i style="font-size:30px" class="fa">&#xf087;</i>{{ $likecount }} Likes</button>
                                                <button type="button" class="match_btn"><i style="font-size:30px" class="fa fa-check-square-o" aria-hidden="true"></i>{{ \App\Match::matchCount() }} Matches</button>
                                            </div>
                                            <div class="col-md-4 padding0 pull-right">
                                                <a href="{{ route('edit.profile') }}" class="btn btn-primary bgred leave_note">Edit Profile</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="settings" role="tabpanel">
                                    <div class="card-body">
                                        <div class="col-md-12 pull-right">
                            <h3 class="font_family">QUESTIONNAIRE</h3>
                            <div class="panel-group mtopbottom" id="accordion" role="tablist" aria-multiselectable="true">

                                @if($useranswer)
                                    @php
                                        $answerarray = json_decode($useranswer->answer_data,true);
                                    @endphp
                                    @foreach($answerarray as $key=>$answer)
                                       @php 
                                           $model = App\Questionnaires::find($key);
                                       @endphp
                                       @php 
                                           $expanded='false';
                                           $collapse='panel-collapse collapse';
                                       @endphp
                                       @if ($loop->first)
                                           @php 
                                               $expanded='true'; 
                                               $collapse='panel-collapse collapse in';
                                           @endphp
                                       @endif
                                       
                                       <div class="panel panel-warning">
                                            <div class="panel-heading" role="tab" id="heading{{ $loop->iteration }}">
                                                <h4 class="panel-title font17">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse{{ $loop->iteration }}" aria-expanded="{{ $expanded }}" aria-controls="collapseOne">
                                                        {{ $model->question_title }}
                                                        <i class="fa fa-plus pull-right"></i>
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id="collapse{{ $loop->iteration }}" class="{{ $collapse }}" role="tabpanel" aria-labelledby="heading{{ $loop->iteration }}">
                                                <div class="panel-body fontclr73">
                                                    @if(count( $answerarray[$model->id] ) > 1 )
                                                        <ul>
                                                            @foreach($answerarray[$model->id] as $getanswer)
                                                               <li>{{ $getanswer }}</li>
                                                            @endforeach
                                                        </ul>
                                                    @else
                                                        @php
                                                            echo current($answerarray[$model->id]);
                                                        @endphp
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                @endif

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->

               
            </div>

<!-- End profile Section -->

@endsection

@section('footer')
<script type="text/javascript">
    $(document).ready(function(){
       $('.slider-for').slick({
          slidesToShow: 1,
          slidesToScroll: 1,
          arrows: false,
          fade: true,
          asNavFor: '.slider-nav',
        	 autoplay: true
        });
        $('.slider-nav').slick({
          slidesToShow: 3,
          slidesToScroll: 1,
          asNavFor: '.slider-for',
          dots: false,
          centerMode: true,
          focusOnSelect: true
        
        });
    });
</script>
@endsection