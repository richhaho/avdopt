@extends('layouts.master')
@section('htmlheader')
<link rel="stylesheet" type="text/css" href="{{ asset('css/slick.css') }}"/><link rel="stylesheet" type="text/css" href="http://kenwheeler.github.io/slick/slick/slick-theme.css"/>
<script type="text/javascript" src="{{ asset('js/slick.js') }}"></script>
@endsection
@section('main-content')

            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">Trails Requests</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item">Trails Requests</li>
                       
                    </ol>
                </div>
                <div>
                    <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button>
                </div>
            </div>
               <div class="container-fluid">
 <div class="col-md-12">
                        <div class="card">
                            <div class="card-body p-b-0">
                                <h4 class="card-title"><b class="vertical_align"><img src="{{ asset('backend/images/trial.png') }}" alt="" class="all_users"><span>TRIAL REQUESTS</span></h4>
                                 </div>
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs customtab" role="tablist">
                                <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#home2" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span> <span class="hidden-xs-down">New</span></a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#profile2" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Accepted</span></a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#messages2" role="tab"><span class="hidden-sm-up"><i class="ti-email"></i></span> <span class="hidden-xs-down">Sent</span></a> </li>
                                  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#decline" role="tab"><span class="hidden-sm-up"><i class="ti-email"></i></span> <span class="hidden-xs-down">Decline</span></a> </li>
                                    <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#ratings" role="tab"><span class="hidden-sm-up"><i class="ti-email"></i></span> <span class="hidden-xs-down">Ratings</span></a> </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="home2" role="tabpanel">
                                    <table>
                            @if($recieved)
                                @foreach($recieved as $request)
                                    <tr> 
                                        <td>{{ $request->userid->name }}, Sent request to you</td> 
                                        <td>
                                            <a class="btn btn-success" href="{{ route('trials.accept', $request->id) }}">Accept</a> 
                                            <a class="btn btn-danger" href="{{ route('trials.decline', $request->id) }}">Cancel</a>
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </table>
                                </div>
                                <div class="tab-pane  p-20" id="profile2" role="tabpanel"> <table class="table">
                            @if($accepted)
                                @foreach($accepted as $request)
                                    <tr> 
                                        <td>You trial request accpeted by, {{ $request->userid->name }}, <small>{{ $request->userid->created_at }} </small> </td>
                                        <td>

                                            <a class="btn btn-info "  data-toggle="modal" data-target="#myModal" data-id="1" link="{{ route('trials.success', $request->id) }}">Successfull</a>
                                            <a class="btn btn-danger "  data-toggle="modal" data-target="#myModal" data-id="2" link="{{ route('trials.unsuccess', $request->id) }}">Unsuccessfull</a>
                                        </td> 
                                    </tr>
                                @endforeach
                            @endif
                        </table></div>
                                <div class="tab-pane p-20" id="messages2" role="tabpanel"> <table>
                            @if($sent)
                                @foreach($sent as $request)
                                    <tr> 
                                        <td>You sent request to {{ $request->matcherid->name }}, on <code>{{  $request->created_at->toFormattedDateString() }}</code> </td>
                                        <td>
                                            <a class="btn btn-danger " href="{{ route('trials.cancelrequest', $request->id) }}">Cancel Request</a>
                                        </td> 
                                    </tr>
                                @endforeach
                            @endif
                        </table></div>
                                <div class="tab-pane p-20" id="decline" role="tabpanel"> <ul>
                            @if($decline)
                                @foreach($decline as $request)
                                    <li> you decline {{ $request->userid->name }} </li>
                                @endforeach
                            @endif
                        </ul></div>
                                <div class="tab-pane p-20" id="ratings" role="tabpanel"> <table class="table table-hover">
                            <tr>
                                <th>#</th>
                                <th>Ratings</th>
                                <th>Comments</th>
                            </tr>
                            @foreach($ratings as $rating)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>
                                        @for ($i = 1; $i <= $rating->rating; $i++)
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                        @endfor
                                    </td>
                                    <td>{{ $rating->comment }}</td>
                                </tr>
                            @endforeach
                        </table></div>
                            </div>
                        </div>
                    </div>
                </div>



<div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Rate Us</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <form action="" method="post" id="forsucccess">
              @csrf
              <div class="form-group">
                   <div class="row">
                    <label for="name" class="col-md-4 col-form-label text-md-right">Rating</label>
                    <input type="hidden" id="hiddenval" value="">
                    <div class="col-md-8">
                        <select id="rating" class="form-control" name="rating">
                            <option value="1">1 Star</option>
                            <option value="2">2 Star</option>
                            <option value="3">3 Star</option>
                            <option value="4">4 Star</option>
                            <option value="5">5 Star</option>
                        </select>
    
                    </div>
                    </div>
              </div>
              
              <div class="form-group">
                   <div class="row">
                    <label for="name" class="col-md-4 col-form-label text-md-right">Comment</label>
    
                    <div class="col-md-8">
                        <textarea class="form-control" name="comment"></textarea>
                    </div>
                    </div>
              </div>
              <button class="btn btn-danger btn-circle pull-right">Submit</button>
          </form>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
        </div>
        
      </div>
    </div>
  </div>
   </div>
@endsection

@section('footer')
<script type="text/javascript">
    $(document).ready(function(){
        $('#accepted .btn').click(function(){
            var href = $(this).attr('link');
            var id = $(this).attr('data-id');
            $('#forsucccess').attr('action',href);
            $('#hiddenval').val(id);
        });
    });
</script>
@endsection