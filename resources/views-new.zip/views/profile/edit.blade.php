@extends('layouts.master')
@section('htmlheader')
<link href="http://demo.expertphp.in/css/dropzone.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/owl.carousel.min.css') }}">
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
<script src="http://demo.expertphp.in/js/dropzone.js"></script>
<script src="{{ asset('backend/js/profile.js') }}" type="text/javascript"></script>
<script src="{{ asset('backend/js/bootstrap-tagsinput.min.js') }}"></script>
@endsection
@section('main-content')
<div class="maincontent backend">
    <div class="container" >
        @if(session()->has('success'))
            <div class="alert alert-success">
                {{ session()->get('success') }}
            </div>
        @endif
        @if(session()->has('danger'))
            <div class="alert alert-danger">
                {{ session()->get('danger') }}
            </div>
        @endif
        <!--====================================================================================================================================================================-->
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <div class="container-fluid">
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-body">
                                <center class="m-t-30"> <img src="{{ ( $user->profile_pic )? url('/uploads/'.$user->profile_pic) : url('images/default.png') }}" class="img-circle" width="150" />
                                    
                                    <h4 class="card-title m-t-10">{{$user->name}}</h4>
                                    <a href="" data-toggle="modal" data-target="#myModales"><i class="fa fa-camera-retro fa-2x"></i></a>
                                    
                                        <div class="modal fade" id="myModales" role="dialog">
    								        <div class="modal-dialog">
            									<!-- Modal content-->
            									<div class="modal-content text-center">
            										<div class="modal-header">
            											<button type="button" class="close" data-dismiss="modal">&times;</button>
            											<h4 class="modal-title font22">Upload Pic</h4>
            										</div>
            										<form action="{{ route('profile.picture') }}" method="post" enctype="multipart/form-data" class=".profile-header-img">
            											<div class="modal-body">
            												<div class="profile-header-img">
            													<img class="rounded-circle" id="profile-img-tag" src="{{ ( $user->profile_pic )? url('/uploads/'.$user->profile_pic) : url('images/default.png') }}" alt="Image" />
            													<!-- badge -->
            												</div>
            												@csrf
            												<div class="form-group">
            													<input type="file" class="form-control-file" name="avatar" id="avatarFile" aria-describedby="fileHelp">
            													<div class="uploadicon">
            														<i class="fa fa-upload" aria-hidden="true"></i>
            														<h2>Upload</h2>
            													</div>
            													<!--small id="fileHelp" class="form-text text-muted">Please upload a valid image file. Size of image should not be more than 2MB.</small-->
            												</div>
            											</div>
            											<div class="modal-footer">
            												<button type="submit" class="btnpad btnred border0 border_radius">Submit</button>
            											</div>
            										</form>
    									        </div>
                                            </div>
    							        </div>
                                    
                                    <div class="row text-center justify-content-md-center">
                                        <div class="col-4"><a href="javascript:void(0)" class="link"><i class="icon-people"></i> <font class="font-medium">254</font></a></div>
                                        <div class="col-4"><a href="javascript:void(0)" class="link"><i class="icon-picture"></i> <font class="font-medium">54</font></a></div>
                                    </div>
                                </center>
                            </div>
                            <div>
                                <hr> </div>
                            <div class="card-body"> <small class="text-muted">Email address </small>
                                <h6>{{ $user->email }}</h6> <small class="text-muted p-t-30 db">Phone</small>
                                <h6>+91 654 784 547</h6> <small class="text-muted p-t-30 db">Address</small>
                                <h6>71 Pilgrim Avenue Chevy Chase, MD 20815</h6>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs profile-tab" role="tablist">
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#settings" role="tab">Profile Edit</a> </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                
                                <!--second tab-->
                                
                                <div class="tab-pane active" id="home" role="tabpanel">
                                    <div class="card-body">
                                        
                                    
                                    
                                    
                                    
                                    
                                    
                                    <form class="form-horizontal form-material" action="{{route('profile.update',$user->id)}}" method="post">
                                        @csrf
                                            <div class="form-group">
                                                <label class="col-md-12">Full Name</label>
                                                <div class="col-md-12">
                                                    @if( !isthisSubscribed() )
                                                        @php
                                                        $disable = "readonly";
                                                        @endphp
                                                        @endif
                                                    <input type="text" name="name" {{ @$disable }} value="{{$user->name}}" class=" form-control form-control-line border_radius {{ $errors->has('name') ? ' has-error' : '' }}">
                                                    @if ( $errors->has('name') )
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('name') }}</strong>
                                                        </span>
                                                        @endif
                                                </div>
                                            </div>
                                            <div class="row mb">
                                            <div class="col-md-4 col-sm-4"><label>My Funs</label></div>
                                            <div class="col-md-8 col-sm-8">
                                                <select name="myfuns[]" class="searchdropdown" multiple>
                                                    @foreach($myfuns as $rows)
                                                        @php
                                                            $selected = '';
                                                            $funs = ( $user->myfuns )? json_decode( $user->myfuns ) : array();
                                                            if($funs){
                                                                if( in_array($rows->id, $funs ) ){
                                                                    $selected = "selected='selected'";
                                                                }
                                                            }
                                                        @endphp
                                                    <option {{ $selected }} value="{{ $rows->id }}" ><?php echo $rows->title ?></option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        @if( !isthisUserSubscribed(Auth::user()->id) )
                                    	<div class="row mb">
                            				<div class="col-md-4 col-sm-4"><label for="user_group">Membership Type</label></div>
                            				<div class="col-md-8 col-sm-8">
                            					<select class="form-control changeUserGroup" id="user_group" onchange="getGenderInfo(this.value,{{ $user->gender }})" name="user_group" required="required" >
                            						@if( $genderrole )    
                            						@foreach( $genderrole as $row )
                            						@if ($loop->first)
                            						<script type="text/javascript">
                            							$(document).ready(function() {
                                                            getGenderInfo(<?php echo $row->id ?>,{{ $user->gender }})
                            							});
                            						</script>
                            						@endif
                            						<option value="{{ $row->id }}" {{ $row->id == $user->group ? 'selected="selected"' : '' }}><?php echo $row->title ?></option>
                            						@endforeach
                            						@endif
                            					</select>
                            				</div>
                            			</div>
                                        <div class="row mb">
                            				<label for="gender" class="col-md-4 col-sm-4 col-form-label text-md-right">Gender</label>
                            
                            				<div class="col-md-8 col-sm-8" id="genderInfodisplay">
                            					@if ($errors->has('gender'))
                            					<span class="invalid-feedback">
                            						<strong>{{ $errors->first('gender') }}</strong>
                            					</span>
                            					@endif
                            				</div>
                                		</div>
                                        <div class="row mb">
                                                <label for="species_id" class="col-md-4 col-sm-4 col-form-label text-md-right">Species</label>
                                                <div class="col-md-8 col-sm-8">
                                                    <select class="form-control" id="species_id" name="species_id" >
                                                        <option value="">Please select</option>
                                                        @if( $species )
                                                            @foreach( $species as $row )
                                                                <option value="{{ $row->id }}" {{$row->id==$user->species_id ? 'selected' : ''}}>
                                                                    <?php echo $row->name;?>
                                                                </option>
                                                            @endforeach
                                                        @endif
                                                    </select>
                                                    @if ($errors->has('species_id'))
                                                        <span class="invalid-feedback">
                                						<strong>{{ $errors->first('species_id') }}</strong>
                                					</span>
                                                    @endif

                                                </div>
                                            </div>
                            			@endif
                                            
                                            <div class="form-group">
                                                <label class="col-md-12">Age</label>
                                                <div class="col-md-12">
                                                    
                                                    <input type="text" name="age" {{ @$disable }} value="{{$user->age}}" class=" form-control form-control-line border_radius {{ $errors->has('age') ? ' has-error' : '' }}">
                                                    @if ( $errors->has('age') )
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('age') }}</strong>
                                                        </span>
                                                        @endif
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>About</label>
                                                <textarea name="about" class="form-control {{ $errors->has('about') ? ' has-error' : ''}} " rows="2">{{$user->about_me}}</textarea>
                                                @if ($errors->has('about'))
                                                <span class="invalid-feedback">
                                                    <strong>{{ $errors->first('about') }}</strong>
                                                </span>
                                                @endif
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-12">
                                                    <button type="submit" placeholder=""  class="btn btn-success pull-right">Update Profile</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    <div class="profile-tab-content text-center" style="display:none" id="profile_second">
                                <h3 class="font28">Photo Album</h3>
                                @if( isthisSubscribed() )
                                <button type="button" class="btnpad btnred mtop70" data-toggle="modal" data-target="#myModal"><i class="fa fa-plus"></i></button>
                                <div class="modal fade" id="myModal" role="dialog">
                                    <div class="modal-dialog">
                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title font22">Photo Album</h4>
                                            </div>
                                            <div class="modal-body">
                                                <h5 class="mtop20 font16">Upload multiple images for Photos Album</h5>
                                                {!! Form::open([ 'route' => [ 'dropzone.uploadfile' ], 'files' => true, 'class' => 'dropzone','id'=>"image-upload"]) !!}
                                                {!! Form::close() !!}
                                            </div>
                            
                                        </div>
                            
                                    </div>
                                </div>
                                <div class="padding60  text-center">
                                    <h4 class="mb30">Upload multiple images for Photo Album</h4>
                                    <div class="grid">
                                        <div class="grid-sizer"></div>
                                        @php
                                        $images = $user->photos;
                                        @endphp
                                        @if( $images )
                                        @foreach($images as $row)
                                        <div class="grid-item">
                                            <a href="javascript:void(0)" class="deleteProduct" data-id="{{ $row->id }}" data-token="{{ csrf_token() }}" ><i class="fa fa-trash" aria-hidden="true"></i></a>
                            
                                            <img src="{{ asset('/uploads/'.$row->image)}}" />
                                        </div>
                                        @endforeach
                                        @endif  
                                    </div>
                                </div>
                                @else
                                <div class="row upgrade">
                                    <div class="col-md-8">
                                        <div class="upgdinfo bggray font300">
                                            <p>Hey {{ ucfirst( Auth::user()->name ) }}!.  Upgrade your membership today to experience unlimited upload photo.</p>
                                        </div>
                                    </div>
                                    <div class="col-md-4">                          
                                        <a style="padding: 18px 0px;" href="{{ url('pricing') }}" class="btn btnred width100">Upgrade Membership</a>
                                    </div>
                                </div>
                                @endif
                            </div>
                            <div class="profile-tab-content" id="profile_third" style="display:none">
                            <h3 class="font28">Questionnaires Settings</h3>
                            <div class="padding60">
                                    <form action="{{route('update.answer',$user->id)}}" method="post">
                                        @csrf
                                        <input type="hidden" value="{{ $user->id }}" name="user_id">
                                        @if($useranswer)
                                            @php
                                                $answerarray = json_decode($useranswer->answer_data,true);
                                            @endphp
                                            
                                        @endif
                                         @foreach ($questionnary as $question) 
                                         <div class="row mb">
                                            <div class="col-md-4 col-sm-4"><label><p>{{ $question->question_title }} </p></label></div>
                                            <div class="col-md-8 col-sm-8">
                                                @switch($question->question_type)
                                                    @case(1)
                                                       <input type="text" class="border_radius" name="answers[{{ $question->id }}][]" value="{{ @$answerarray[$question->id][0] }}">
                                                    @break
                                                    @case(2)
                                                        @php 
                                                           $options = json_decode($question->question_data);
                                                       @endphp
                                                       <select name="answers[{{ $question->id }}][]" class="border_radius">
                                                          @foreach ($options->options as $option)
                                                          @if($useranswer)
                                                           <option value="{{ $option }}" @if(@$answerarray[$question->id][0]==$option ) selected @endif >{{ $option }}</option>
                                                           @else
                                                           <option value="{{ $option }}">{{ $option }}</option>
                                                           
                                                           @endif
                                                           @endforeach 
                                                       </select>
                                                    @break
                                                    
                                                    @case(3)
                                                        @php 
                                                            $options = json_decode($question->question_data);
                                                            $seloptions = @$answerarray[$question->id];
                                                        @endphp
                                                        @foreach ($options->options as $option)
                                                            @php
                                                                $sel = "";
                                                            @endphp
                                                            @if($useranswer)
                                                            @if( in_array($option, $seloptions ) )
                                                                @php
                                                                    $sel = "checked='checked'";
                                                                @endphp
                                                            @endif
                                                             @endif
                                                            <input type="checkbox" {{ $sel }} value="{{ $option }}" name="answers[{{ $question->id }}][{{$loop->iteration}}]" >{{ $option }}
                                                        @endforeach
                                                    @break
                                                
                                                    @default
                                                        <textarea name="answers[{{ $question->id }}][]">{{ @$answerarray[$question->id][0] }}</textarea>
                                                @endswitch                                 
                                            </div>                                  
                                        </div>
                                        @endforeach                                 
                                        <div class="row mtopbottom">
                                            <div class="col-md-4">
                                            </div>
                                            <div class="col-md-8">
                                                <button type="text" placeholder="" class="btnpad bgred pull-right border_radius">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ==================================================================================================================================================== -->
                <!-- End PAge Content -->
            </div>
        </div>
    </div>
    </div>
    
    

    
    
</div>
@endsection
@section('footer')
<script type="text/javascript">

$(document).ready(function(){
$(".deleteProduct").click(function(){
    // alert('dfgfd');
    var nowclass = $(this).parents('.grid-item');
        var id = $(this).attr("data-id");
        var token = $(this).attr("data-token");
        $.ajax(
        {
            url: "album/delete/"+id,
            method: 'post',
            dataType: "JSON",
            data: {
                "id": id,
                "_token": token
            },
            success: function ()
            {
                console.log("It works");
                nowclass.remove();
            }
        });

    });
    
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#avatarFile").change(function(){
        readURL(this);
    });
});  

var $grid = $('.grid').isotope({
  itemSelector: '.grid-item',
  columnWidth: 160,
  gutter: 20,
  percentPosition: true,
  masonry: {
    columnWidth: '.grid-sizer'
  }
});
</script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.searchdropdown').select2({
            placeholder: 'Select Funs',
          multiple: true
        });
    });
</script>
@endsection

