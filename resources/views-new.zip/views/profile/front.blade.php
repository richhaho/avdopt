@extends('v7.frontend')
@section('head')
<link rel="stylesheet" type="text/css" href="{{ asset('css/slick.css') }}"/>
<link rel="stylesheet" type="text/css" href="http://kenwheeler.github.io/slick/slick/slick-theme.css"/>
<script type="text/javascript" src="{{ asset('js/slick.js') }}"></script>
	<script src="{{ asset('js/common.js') }}" type="text/javascript"></script>
 @yield('head')
    <!--<link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/style.css') }}"-->
    
 <style>
    .colorred {
    color: rgb(238,60,60) !important;
    }
        
    ul.myfun_list li {
    /* display: block; */ 
    display: inline-block;
    margin-bottom: 2rem;
    padding: 2px;
    }
        
    .start_chat, .show_message {
    display: inline-block;
    }
.myfun_list li a span {
    background-color: #fff;
    border-radius: 50%;
    display: inline-block;
    height: 9px;
    left: 7px;
    position: absolute;
    top: 14px;
    width: 9px;
    box-shadow: 0px 1px 1px #000 inset;
}
.chat_span {
	background-color: #eee;
	border-bottom-left-radius: 4px;
	border-top-left-radius: 4px;
	box-shadow: 0 4px 0 0 #ccc;
	display: inline-block;
	margin: 0 0 0 3px;
	padding: 7px 0px 12px 17px;
	position: relative;
}
.chat_span::before {
    background-color: #eee;
    box-shadow: 0 4px 0 0 #ccc;
    content: "";
    height: 39px;
    right: -17px;
    position: absolute;
    top: 0;
    transform: skewX(-24deg);
    width: 29px;
    margin: 0px;
}

.chat_span i {
	color: #2DB642;
	font-size: 18px;
	font-weight: normal;
}
.col-md-4.padding0.about_me {
    background: #fff;
    width: 395px;
}
.chat_note {
    background-color: #2db642;
    border: 0 none;
    border-radius: 4px;
    box-shadow: 0 4px 0 0 #218a2b;
    color: #fff;
    font-family: "Bubblegum Sans",cursive;
    font-size: 16px;
    padding: 8px 18px 12px 32px;
}
.padding0 {
	padding: 0;
}

.leave_note {
	background-color: #02b1e8;
	border: 0 none;
	border-radius: 4px;
	box-shadow: 0 3px 0 0 #078ba4;
	color: #fff;
	font-family: "Bubblegum Sans",cursive;
	font-size: 15px;
	margin-left: 0;
    padding: 8px 18px 12px 32px;
}
.right-section.profile_ad {
    background: #fff;
    box-shadow: 0 0 5px #ccc;
    padding: 14px;
}
.message_span {
    background-color: #eee;
    border-bottom-right-radius: 4px;
    border-top-right-radius: 4px;
    box-shadow: 0 4px 0 0 #ccc;
    display: inline-block;
    margin: 0 0 0 3px;
    padding: 11px 18px 9px 7px;
    position: relative;
    top: 4px;
}

.message_span::before {
    background-color: #eee;
    box-shadow: 0 4px 0 0 #ccc;
    content: "";
    height: 40px;
    left: -18px;
    position: absolute;
    top: 0;
    transform: skewX(-24deg);
    width: 29px;
    margin-top: 0;
}

.message_span i {
	color: #2D4760;
	font-size: 15px;
	font-weight: normal;
}
   .left-section {
	display: inline-block;
	width: 395px;
	vertical-align: top;
	padding: 11px;
	background: #fff;
	margin-right: 18px;
}

.mtopbottom80 {
	margin: 80px 0px;
	background: #f5f5f5;
	padding: 30px;
}
.hrt-sec {
	text-align: right;
	padding-right: 2rem;
	padding:1rem;
}

.profile-section i.fa.fa-heart-o.addtowishlist.show_error_if_found, .profile-section i.fa.addtowishlist.show_error_if_found.fa-heart.colorred {
	margin-left: 24px;
	margin-bottom: 0;
}

.hrt-sec i {
	color: #ff0404 !important;
}

i.fa.fa-heart-o, i.fa.fa-heart {
	margin-bottom: 10px;
}



.padding0 {
	padding: 0;
}


.slider-thumb {
	max-width: 90%;
	text-align: center;
	margin: auto;
}

.slider-thumb {
	text-align: center;
}

.slider-nav img {
	height: 120px;
	object-fit: cover;
	padding: 0 5px;
	width: 120px;
}


.profile_info {
	background: #fff none repeat scroll 0 0;
	box-shadow: 0 0 5px #ccc;
}

.right-section {
	display: inline-block;
	margin-left: -4px;
	padding: 23px 20px 35px 30px;
	vertical-align: top;
	width: calc(100% - 415px);
}


.like_btn, .match_btn {
	background: transparent none repeat scroll 0 0;
	border: 1px solid #eaeaea;
	border-radius: 4px;
	font-size: 21px;
	padding: 5px 25px;
	display: inline-flex;
}

.colorred {
    color: rgb(238,60,60) !important;
}

.slick-slide.slick-current {
	/*width: 395px !important;*/
}
.like_btn, .match_btn {
	float: right;
	margin-left: 1rem;
}

.like_btn {
	color: #ee3c3c;
}

.like_btn i, .match_btn i {
	display: inline-block;
	font-size: 25px;
	padding-right: 8px;
}

.profile_info span.reportblock, .profile_info i {
	text-align: left;
	display: block;
}
i {
	cursor: pointer;
	position: relative;
}

.match_btn {
	color: #30a6cc;
	margin-left: 15px;
}

.profile_info span.reportblock, .profile_info i {
	text-align: left;
	display: block;
}

.profile_info span.reportblock {
	margin-top: 20px;
}
.col-md-12.pull-right {
    background: #fff;
        box-shadow: 0 0 5px #ccc
}
.reportblock {
	margin-top: 0 !important;
}
.reportblock {
	margin-top: 0 !important;
}
.profile_info a {
	text-decoration: underline;
	width: 100%;
	color: #727272;
	font-weight: 600;
}

ul {
	padding: 0;
}

ul, ol {
	list-style: none;
	list-style-image: none;
	margin: 0;
	padding: 0;
	color: #858585;
	font-size: 14px;
	line-height: 24px;
	margin-bottom: 20px;
}

.profile_info ul li {
	border-bottom: 1px solid #eee;
	color: #4f4e4e;
	padding: 7px 0;
	position: relative;
	width: 100%;
}

img {
	max-width: 100%;
}

.profile_info ul li span {
	vertical-align: middle;
	padding-left: 7px;
}

.font17 {
	font-size: 17px;
}

ul li {
	list-style-type: none;
}

ul li, ol li {
	font-size: 15px;
	line-height: 28px;
}

.profile_info ul li span {
	vertical-align: middle;
	padding-left: 7px;
}


.right-section {
	display: inline-block;
	margin-left: -4px;
	padding: 23px 20px 35px 30px;
	vertical-align: top;
	width: calc(100% - 415px);
}
.ad_box {
	background: #000 none repeat scroll 0 0;
	color: #fff;
	font-size: 30px;
	min-height: 100px;
	padding: 36px 18px;
	text-align: center;
}
/*h3.font_family.mtop40 {*/
/*    margin: 9px 0;*/
/*}*/

.about_me h3 {
    margin: 16px 17px!important;
        margin-bottom: 0;
}
.ad_box {
	color: #fff;
	font-size: 30px;
	text-align: center;
}   
.myfun_list li a {
    border-radius: 13px;
    color: #fff;
    font-size: 10px;
    padding: 11px 11px 11px 18px;
    position: relative;
    text-decoration: none;
    text-transform: uppercase;
}
.bgred {
    background: #EB3939 !important;
    color: #fff;
    padding: 1rem;
    font-size: 19px;
}
.col-md-6.padding0.about_me {
	padding: 20px;
	background: #fff;
}
.profile-section {
	margin-bottom: 3rem;
}
.fl_sec {
	float: left;
	width: 100%;
	margin-top: 1rem;
}
.t.start_chat {
	margin-top: 5px;
}
.ad_box.down {
    color: #fff;
    font-size: 30px;
    text-align: center;
    padding: 188px 18px;
}
.featuredclass_6 h3 {
    background-color: #000;
    border-radius: 12px;
    color: #FFEE58;
    display: inline-block;
    font-size: 25px;
    margin: 0 auto;
    padding: 15px 10px 15px 10px;
    position: relative;
    text-align: center;
}
.profile_section .Featured_members h3 img {
    left: -12px;
    position: absolute;
    top: 9px;
    width: 15%;
}
.featuredmembers_img {
    color: #fff;
    display: inline-block;
    margin-top: -18px;
    padding: 58px 0px;
    background: #ee3c3c;
    background: -moz-linear-gradient(top, #f28e54 3%, #ee3c3c 73%);
    background: -webkit-linear-gradient(top, #f28e54 3%,#ee3c3c 73%);
    background: linear-gradient(to bottom, #f28e54 3%,#ee3c3c 73%);
    filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ee3c3c', endColorstr='#f28e54',GradientType=0 );
}
.featuredclass_6 .featuredmembers_img .vertical_align a {
    color: #fdee57;
    font-size: 14px;
    width: 100%;
    height: 0;
}
.featuredclass_6 .vertical_align button {
    background-color: #fdeb58;
    border: 0 none;
    border-radius: 50%;
    color: #000;
    font-weight: bold;
    height: 45px;
    text-align: center;
    width: 45px;
}
.col-md-12.col-sm-12.padding0.mtop80.Featured_members {
    margin-top: 5rem;
}
       
       .Featured_members a {
    color: #0ec2eb;
    font-style: italic;
    font-weight: bold;
    font-size: 22px;
    margin-top:20px;
} 
.Usergradientbg {
    background: rgba(0, 0, 0, 0) linear-gradient(to right, #d9d900 27%, #25c8ff 73%) repeat scroll 0 0;
    border-radius: 6px;
    bottom: 44%;
    color: #000;
    font-size: 15px;
    font-weight: bold;
    padding: 0px 4px;
    position: absolute;
    right: 33px;
    text-transform: uppercase;
    top: -4px;
    margin-top: 10px;
    height: 32px;
}
.profile_info ul li span {
    vertical-align: middle;
    padding-left: 7px;
}
.Usergradientbg > span {
    border: 1px solid #fff;
    border-radius: 4px;
    padding: 0 15px;
}
    </style>
@endsection
@section('content')
<div class="maincontent backend">
    <div class="content">  
<!-- Start profile Section -->
        <div class="profile_section mtopbottom80">
            @if(session()->has('message'))
                <div class="alert alert-success">
                    {{ session()->get('message') }}
                </div>
            @endif
            @php
                $message = '';
                $subnotrequired = 0;
                if( Auth::user() ){
                    if( !isthisSubscribed() ){
                        $subnotrequired = 1;
                        $message = "You have subscribe first to take this feature";
                    }
                }else{
                    $message = "You have to sign in first";
                }
            @endphp
            <div class="container">
                <div class="profile-section">
                  
                    <div class="left-section">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="user_sec"><h4>{{ ucfirst( $user->name ) }}</h4></div>
                            </div>
                            <div class="col-md-6">
                                <div class="hrt-sec">
                            @if( \App\Heart::is_in_wishlist( $user->id ) )
                                <i class="fa fa-heart colorred addtowishlist show_error_if_found" data-errormsg="{{ $message }}" data-user="{{ base64_encode($user->id) }}" style="font-size:30px;color:#c0c0c0"></i>
                            @else
                                <i class="fa fa-heart-o addtowishlist show_error_if_found" data-errormsg="{{ $message }}" data-user="{{ base64_encode($user->id) }}" style="font-size:30px;color:#c0c0c0"></i>
                            @endif
                            
                          
                        </div>
                            </div>
                        </div>
                        
                         
                          
                        <div class="slider-for">
                            <div style="background-image:url({{ ( $user->profile_pic )? url('/uploads').'/'.$user->profile_pic : url('/images/default.png')}});background-size:cover;background-position:50% 50%;height:450px; width:373px;"></div>
                            @php
                                $images = @$user->photos;
                            @endphp
                            @if( $images )
                                @foreach($images as $row)
                                    <div style="background-image:url({{ asset('/uploads/'.$row->image)}});background-size:cover;background-position:50% 50%;height:450px; width:106px;"> </div>
                                @endforeach
                            @endif
                        </div>
                        
                         
                    </div>
                    
                    
                    
                    
                    
                    
                    <div class="right-section profile_info">
                        <div class="col-md-12 col-sm-12">
                            <div class="col-md-12 ">
                                <button type="button" data-user="{{ base64_encode($user->id) }}" data-subnotrequired={{ $subnotrequired }} data-errormsg="{{ $message }}" class="like_btn show_error_if_found">
                                    <i  class="fa">&#xf087;</i>
                                    {{ $likecount }} Likes
                                </button>
                                <button type="button" class="match_btn"><i class="fa fa-check-square-o" aria-hidden="true"></i>{{ \App\Match::matchCount($user->id) }} Matches</button>
                            
                            @if( Auth::user() )
                                @if($user->id != Auth::user()->id)
                                <span class="reportblock">
                                    <a href="javascript:void(0)" class="reportorblock" data-toggle="modal" data-id="1" data-target="#myModal">Report </a>
                                    or 
                                    <a href="javascript:void(0)" class="reportorblock" data-toggle="modal" data-id="2" data-target="#myModal">Block user</a>
                                </span>
                                @endif
                            @else
                                <span class="reportblock">
                                    <a href="javascript:void(0)" data-errormsg="{{ $message }}" class="show_error_if_found reportorblock">Report </a>
                                    or 
                                    <a href="javascript:void(0)" data-errormsg="{{ $message }}" class="show_error_if_found reportorblock">Block user</a>
                                </span>
                            @endif
                            </div>
                           
                        </div>
                        <div class="col-md-6">
                            <ul>
                                <li class="font17"><img src="{{url('/')}}/frontend/images/user.png" alt="Profile Icon" title="Profile Icon"> <span>Name: {{ ucfirst( $user->name ) }} </span></li>
                                <li class="font17"><img src="{{url('/')}}/frontend/images/membership.png" alt="Membership Icon" title="Membership Icon">  <span>Membership Type: {!! getGroupTagWithColor($user->id) !!}</span> </li>
                                <li class="font17"><img src="{{url('/')}}/frontend/images/age.png" alt="Age Img" title="Age Img">  <span>Age: {{ ( $user->age )? $user->age . ' Years' : '' }}  </span></li>
                                <li class="font17"><img src="{{url('/')}}/frontend/images/gender.png" alt="Gender Icon" title="Gender Icon"> <span> Gender: {{ @$user->usergender->title }}</span></li>
                                
                            </ul>
                        </div>
                        
                        <div class="col-md-6">
                            <ul>
                                
                                <li class="font17"><img src="{{url('/')}}/frontend/images/user.png" alt="Species Icon" title="Species Icon"> <span>Species: {{ $user->species?$user->species->name:'N/A' }} </span></li>
                                <li class="font17"><img src="{{url('/')}}/frontend/images/join_date.png" alt="Join Date Icon" title="Profile Icon"> <span> Join Date: {{ ( $user->created_at )? date("F j, Y, g:i A", strtotime($user->created_at) ) : '' }}</span></li>
                                <li class="font17"><img src="{{url('/')}}/frontend/images/last_login.png" alt="last Login Icon" title="Profile Icon"> <span> Last Seen: {!! $user->last_seen_ago_html !!}</span></li>
                            </ul>
                        </div>
                        
                        <div class="col-md-12">
                         <p>{{ $user->about_me}}</p>   
                        </div>    
                        
                        
                    </div>
                    @php
                        $images = $user->photos;
                    @endphp
                    @if( $images )
                        <div class="left-section mtopbottom20">
                            <div class="slider-thumb">
                                <div class="slider-nav">
                                    <div><img  src="{{ ( $user->profile_pic )? url('/uploads').'/'.$user->profile_pic : url('/images/default.png')}}" alt="Profile Img" title="Profile Img"> </div>
                                    @foreach($images as $row)
                                        <div><img  src="{{ asset('/uploads/'.$row->image)}}" alt="Profile Img" title="Profile Img"> </div>
                                    @endforeach
                                 </div>
                            </div>
                            <div class="fl_sec">
                        <div class="col-md-6 padding0">
                          <div class="t start_chat">
                              
                                <span class="chat_span"><i class="fa fa-commenting" aria-hidden="true"></i></span>
                                @if( isthisSubscribed() )
                                    <a class=" chat_note" href="{{ url('chat') }}">START CHAT </a>
                                @else
                                    <a class=" chat_note show_error_if_found"  data-errormsg="{{ $message }}" href="javascript:void(0)">START CHAT </a>
                                @endif
                            </div>
                            </div>
                            <div class="col-md-6  padding0">
                             <div class=" padding0 msg_chat">
                                @if( Auth::user() )
                                    <button type="button" class=" leave_note" data-toggle="modal" data-id="1" data-target="#myModalNote">MESSAGE</button>
                                @else    
                                    <button type="button" class=" leave_note show_error_if_found" data-errormsg="{{ $message }}" >MESSAGE</button>
                                @endif
                                <span class="message_span"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                            </div>
                            </div>
                            </div>
                        </div>
                        <!-- Profile Ad -->
                    <div class="right-section profile_ad">
                            <div class="ad_box up">
                               <span> AD BANNER </span>
                           </div>
                    </div>
                     <!-- End Profile Ad -->
                    @endif
                </div>

                <div class="col-md-12 col-sm-12 mtop80 padding0 ">
                    <div class="col-md-4 padding0 about_me">
                         <h3 class="font_family mtop40">MY FUN (Tag Along)</h3>
                        <ul class="myfun_list">
                            
                            @if($user->myfuns)
                                @php
                                    $titles = array();
                                    if( $user->myfuns ){
                                        $funIDs = json_decode($user->myfuns);
                                        if( count( $funIDs ) ){
                                            $titles = App\MyFun::whereIn('id', $funIDs)->get();
                                        }
                                    }
                                @endphp
                                @if($titles)
                                    @foreach($titles as $title)
                                        <li><a href="#" class="bgred"><span></span>{{ $title->title }}</a></li>
                                    @endforeach
                                @endif
                            @endif
                        </ul>
                    </div>
                    <div class="col-md-7">
                        <div class="col-md-12 pull-right">
                            <h3 class="font_family bgred">QUESTIONNAIRE</h3>
                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

                                @if($useranswer)
                                    @php
                                    
                                        $answerarray = json_decode($useranswer->answer_data,true);
                                    @endphp
                                    @if($answerarray)
                                    @foreach($answerarray as $key=>$answer)
                                       @php 
                                           $model = App\Questionnaires::find($key);
                                       @endphp
                                       @php 
                                           $expanded='false';
                                           $collapse='panel-collapse collapse';
                                       @endphp
                                       @if ($loop->first)
                                           @php 
                                               $expanded='true'; 
                                               $collapse='panel-collapse collapse in';
                                           @endphp
                                       @endif
                                       
                                       <div class="panel panel-warning">
                                            <div class="panel-heading" role="tab" id="heading{{ $loop->iteration }}">
                                                <h4 class="panel-title font17">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse{{ $loop->iteration }}" aria-expanded="{{ $expanded }}" aria-controls="collapseOne">
                                                        {{ $model->question_title }}
                                                        <i class="fa fa-plus pull-right"></i>
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id="collapse{{ $loop->iteration }}" class="{{ $collapse }}" role="tabpanel" aria-labelledby="heading{{ $loop->iteration }}">
                                                <div class="panel-body fontclr73">
                                                    @if(count( $answerarray[$model->id] ) > 1 )
                                                        <ol>
                                                            @foreach($answerarray[$model->id] as $getanswer)
                                                               <li style="width: 100%;">{{ $getanswer }}</li>
                                                            @endforeach
                                                        </ol>
                                                    @else
                                                        @php
                                                            echo current($answerarray[$model->id]);
                                                        @endphp
                                                    @endif
                                                </div>
                                            </div>
                                    </div>
                                    @endforeach
                                    @endif
                                @endif
                            </div>
                        </div>
                    </div>
                    
                <!-- Featured Members -->
                <div class="col-md-12 col-sm-12 padding0 mtop80 Featured_members">
                    <div class="col-md-6 padding0 mtop40 text-center">
                        <div class="ad_box down">
                            <span>AD BANNER</span>
                        </div>
                        <a href="#" class="font22 mtop20 inline_block">Click here to advertise with us</a>
                    </div>
                    @include('includes.features', ['featurecount'=>6])
                    </div>
                    <!-- End Featured Members  -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End profile Section -->
<div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      <form class="formreportblock" method="post" action="{{ route('profile.blockreport') }}">
           @csrf
        <!-- Modal Header -->
        <div class="modal-header">
          <h2 class="modal-title"></h2>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
            <input type="hidden" value="{{ ucfirst( $user->id ) }}" name="block_id" />
            <input type="hidden" value="" id="type" name="type" />
            <div class="form-group">
                
            <label class="col-form-label">Reason</label>
            <select name="reason" class="form-control" >
                @php
                    $reasons = App\Reason::all();
                @endphp
                @if($reasons)
                    @foreach($reasons as $reason)
                        <option value="{{ $reason->name }}">{{ $reason->name }}</option>
                    @endforeach
                @endif
            </select>
            <br>
            </div>
            <div class="form-group">
            <label class="col-form-label">Reason Description</label>
            <textarea type="text" class="form-control" name="description"></textarea>
            <br>
            </div>
            <div class="form-group">
                <label></label>
            <button id="subbtn" style="text-transform:capitalize" class="btnpad btnred border_radius"></button>
            </div>
        </div>
        
        </form>
      </div>
    </div>
  </div>
  <div class="modal fade" id="myModalNote">
      <div class="modal-dialog">
      <div class="modal-content">
      <form class="formreportblock" method="post" action="{{ route('messages.store') }}">
           @csrf
        <!-- Modal Header -->
        <div class="modal-header">
          <h2 class="modal-title">Send Note to {{ ucfirst( $user->name ) }}</h2>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
            <input type="hidden" value="{{ ucfirst( $user->id ) }}" name="reciever_id" />
            <div class="form-group">
            <label class="col-form-label">Note</label>
            <select name="note" id="noteselect" class="form-control">
                @php
                    $groupid = 1;
                    if( Auth::user() ){
                        $groupid = Auth::user()->group;
                    }
                    $notes = App\Note::where('user_group', $groupid)->get();
                    if($notes){
                        foreach($notes as $note){
                            echo '<option value="'.$note->note.'">'.$note->note.'</option>';
                        }
                    }
                @endphp
                @if ( isthisSubscribed() )
                    <option value="other">Other</option>
                 @endif
            </select>
            @if ( isthisSubscribed() )
                <div class="textareanote"></div>
            @else
                
            @endif
            <br>
            </div>
            <div class="form-group">
                <label></label>
            <button id="subbtn" style="text-transform:capitalize" class="btnpad btnred border_radius">Send</button>
            </div>
        </div>
        
        </form>
      </div>
    </div>
  </div>
  
@endsection

@section('scripts')
<script type="text/javascript">
    $(document).ready(function(){

        $("#noteselect").change(function(){
        var selectvalue = $("#noteselect option:selected").val();
        if(selectvalue=='other'){
            $(this).remove();
            $('.textareanote').append('<textarea type="text" class="form-control" name="note"></textarea>');
        }
    });
        $('.reportorblock').click(function(){
            var id = $(this).attr('data-id');
            if(id==1){
                var type = 'report';
                var header = 'Report User <code>{{ ucfirst( $user->name ) }}</code>';
            }
            else{
                var type = 'block';
                var header = 'Block User <code>{{ ucfirst( $user->name ) }}</code>';
            }
            $('#type').val(type);
            $('#subbtn').text(type);
            $('.formreportblock .modal-title').html(header);
        });
        $('.slider-for').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            fade: true,
            asNavFor: '.slider-nav'
        });
        $('.slider-nav').slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            asNavFor: '.slider-for',
            dots: false,
            centerMode: false,
            focusOnSelect: true
        });
            // masonary
        var $grid = $('.grid').isotope({
          itemSelector: '.grid-item',
          columnWidth: 160,
          gutter: 20,
          percentPosition: true,
          masonry: {
            columnWidth: '.grid-sizer'
          }
        });
    });
</script>
@endsection