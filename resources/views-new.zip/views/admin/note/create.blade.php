@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">                       
        
         <!-- Start Upgrade Membership ---->
            <div class="membership">
                <div class="container-fluid">
                    <h4 class="inline_block font20"><i class="fa fa-envelope"></i>Create Note</h4>        
                     
                </div>
                 <hr>
            </div>
            <!-- End Upgrade Membership ---->
  
        <!-- Start Message Tabs -->
        <div class="msgtabs">
            <div class="container-fluid">
                <div class="tab-content">
                    <form class="form_inline fullwidth mtop40" method="POST" action="{{route('note.store')}}">
    			        {{ csrf_field() }}					
        			    <div class="form-group">
                           <div class="row">
                                <label for="note" class="col-md-4 col-form-label text-md-right">Note</label>
                                <div class="col-md-8">
                                    <input type="hidden" name="user_group" value="{{ $groupId }}"/>
                                    <textarea id="note" class="form-control" name="note" value="" required=""></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
						    <div class="row">
    							<div class="col-md-3"></div>
    							<div class="col-md-9"><button type="submit" class="btnpad btnred pull-right border_radius">Submit</button></div>
							</div>
						</div>
                    </form>
                        
                                                 
                </div>
                    
            </div>
        </div>
    </div>
    <!-- End Message Tabs -->

</div>      
@endsection