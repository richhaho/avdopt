@extends('layouts.master')

@section('main-content')
<div class="maincontent">
        <div class="content bgwhite">                       
            
            <!-- Start Upgrade Membership ---->
            <div class="membership">
                <div class="container-fluid">
                    <h4 class="inline_block font22"><b><img src="{{ asset('backend/images/notes2.png') }}" alt="Note" title="Img" class="">Notes</b></h4>                  
                    <a href="{{route('note.create', $groupId )}}" class="btn btnred pull-right">Add Note</a>
                    <a href="{{route('admin.usergroup')}}" class="btn btnred pull-right">Back To User Groups</a>
                     
                </div>
                 <hr>
            </div>
            <!-- End Upgrade Membership ---->


            <!-- Start Message Tabs -->
            <div class="msgtabs pt50">
                <div class="container-fluid">
                    @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif
                  <div class="tab-content">
                        <div id="inbox" class="tab-pane fade in active">

                            <table class="table table-striped table-bordered">
                                    <tr>
                                       <th>Sr.No.</th>
                                       <th>Note Title</th>
                                       <th>User Group</th>
                                        <th>Action</th>
                                    </tr>
                                    @foreach($notes as $note)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $note->note }}</td>
                                        <td>{{ $note->usergroup->title }}</td>
                                        <td>
                                            <a href="{{ route('note.edit', ['groupId'=>$groupId,'id'=> $note->id] ) }}" class="btn btn-info btn-circle"><i class="fa fa-pencil"></i></a>
                                            <a onclick="return confirm('Are you sure you want to delete this user?')" href="{{ route('note.delete', $note->id) }}" class="btn btn-danger btn-circle"><i class="fa fa-trash-o"></i></a>
                                            
                                        </td>
                                    </tr>
                                    @endforeach

                                </table>
                                 {{ $notes->links() }}
                              
                            </div>
                            
                                                     
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- End Message Tabs -->

        </div>      
    </div>
@endsection
