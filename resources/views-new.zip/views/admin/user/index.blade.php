@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite"> 
        <!-- Start Upgrade Membership ---->
        <div class="membership">
            <div class="container-fluid">
                    <h4 class="inline_block font22">
                        <b class="vertical_align"><img src="{{ asset('backend/images/allusers.png') }}" alt="Report" title="Img" class="all_users">USERS</b>
                    </h4>                        
                        <a href="{{url('admin/reports')}}" style="margin:0 10px" class="btn btnred pull-right">Reports</a>
					    <a href="{{url('admin/blocks')}}" style="margin:0 10px" class="btn btnred pull-right">Blocks</a>
					    <a href="{{route('users.create')}}" style="margin:0 10px" class="btn btnred pull-right">Add User</a>
                </div>
           <hr>
        </div>
        <!-- End Upgrade Membership ---->


        <!-- Start Message Tabs -->
        <div class="msgtabs mtop30">
            <div class="container-fluid">
                @if(session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="tab-content">
                    <div id="inbox" class="tab-pane fade in active">
                        <table class="table table-bordered">
                            <th>#</th>
                            <th>Name</th>
                            <th>Display Name</th>
                            <th>Roles</th>
                            <th>Email</th>
                            <th>Gender</th>
                            <th>Species</th>
                            <th>Group</th>
                            <th>Age</th>
                            <th>Action</th>
                            @foreach($users as $user)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{$user->name}}</td>
                                <td>{{$user->displayname}}</td>
                                <td>{{ @$user->role->role }}</td>
                                <td>{{$user->email}}</td>
                                <td>{{ @$user->usergender->title}}</td>
                                <td>{{ $user->species?$user->species->name:'N/A' }}</td>
                                <td>{{ @$user->usergroup->title }}</td>
                                <td>{{$user->age}}</td>
                                <td>
                                    <a href="{{route('viewprofile', base64_encode( $user->id ))}}" class="btn btn-info btn-circle"><i class="fa fa-eye"></i></a>
                                    <a href="{{route('users.edit',$user->id)}}" class="btn btn-info btn-circle"><i class="fa fa-pencil"></i></a>
                                    @if(@$user->id!=1)
                                    <!--a onclick="return confirm('Are you sure you want to delete this user?')" href="{{route('users.delete',$user->id)}}" class="btn btn-danger btn-circle"><i class="fa fa-trash-o"></i></a-->
                                    <a href="#" class="btn btn-info btn-circle btn-warning warningtouser" data-user="{{$user->name}}" data-id="{{$user->id}}" data-toggle="modal" data-target="#myModalWarning" title="Warning"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i></a>
                                    @if(@$user->suspend==0)
                                        <a onclick="return confirm('Are you sure you want to suspend this user?')" href="{{route('profile.suspend', $user->id )}}" class="btn btn-info btn-circle btn-danger" title="Suspend"><i class="fa fa-ban" aria-hidden="true"></i></a>
                                    @else
                                        <a onclick="return confirm('Are you sure you want to active this user?')" href="{{route('profile.active', $user->id )}}" class="btn btn-info btn-circle btn-success" title="Suspend"><i class="fa fa-check-circle" aria-hidden="true"></i></a>
                                    @endif
                                    @endif
                                    </td>
                                </td>
                            </tr>   
                            @endforeach     
                        </table>
                    </div>
                </div>

            </div>
            {{ $users->links() }}
        </div>
    </div>
</div> 
<div class="modal fade" id="myModalWarning" role="dialog">
    <form id="warningform" method="post" action="">
        @csrf
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Warning Notification to <code id="warninguser"></code> Profile</h4>
        </div>
        <div class="modal-body">
          <p><textarea name="warningmessage" id="warningmessage" placeholder="Warning Message" class="border_radius"></textarea></p>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btnpad btnred pull-right border_radius border0">Submit</button>
        </div>
      </div>
      
    </div>
    </form>
  </div>
@endsection
@section('footer')
<script type="text/javascript">

$(document).ready(function(){
    $(".warningtouser").click(function(){
        var username = $(this).attr('data-user');
        var userid = $(this).attr('data-id');
        var urlaction = 'http://avdopt-saurabhrishu.c9users.io/profile/warning/'+userid;
        $('#warninguser').text(username);
        $('#warningform').attr('action',urlaction);
        
    });
});  


</script>

@endsection