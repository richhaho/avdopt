@extends('layouts.master')

@section('main-content')
<div class="maincontent">
        <div class="content bgwhite">                       
            
            <!-- Start Upgrade Membership ---->
            <div class="membership">
                <div class="container-fluid">
                   <h4 class="inline_block font22"><b class="vertical_align"><img src="{{ asset('backend/images/genderrole.png') }}" alt="Gender" title="Img" class="gender_img">GENDER ROLE</b></h4>               
                            <a href="{{route('admin.create.gender')}}" class="btn btnred pull-right">Add Gender</a>
                 
                </div> 
                <hr>
            </div>
            <!-- End Upgrade Membership ---->


            <!-- Start Message Tabs -->
            <div class="gender_box paddingtb20">
                <div class="container-fluid">
                    
                  <div class="tab-content">
                        <div id="inbox" class="tab-pane fade in active">

                            <table class="table table-bordered">
                                    <?php $i=1; ?>
                                       
                                        <th>Sr.No.</th>
                                        <th>Title</th>
                                        <th>Action</th>
                         @foreach($gender as $row)
                                     <tr>

                                        <td>{{$i++}}</td>
                                        <td>{{$row->title}}</td>
                                        <td><a href="{{route('gender.edit',$row->id)}}" class="btn btn-info btn-circle"><i class="fa fa-pencil"></i></a>
            <a href="{{route('gender.delete',$row->id)}}" class="btn btn-danger btn-circle"><i class="fa fa-trash-o"></i></button></td>
                                     

                                     </tr>   
                                    
                                  @endforeach  
                                   
                                </table>
                              
                            </div>                       
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- End Message Tabs -->

        </div>      
    </div>
@endsection
