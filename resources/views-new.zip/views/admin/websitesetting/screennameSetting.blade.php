@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">                       

        <!-- Start Upgrade Membership ---->
        <div class="membership">
            <div class="container-fluid">
                    <h4 class="inline_block font22"><b class="vertical_align"><img src="{{ asset('backend/images/setamount.png') }}" alt="Img" title="Img" class="announcement">User Screen Name Settings</b></h4>
                </div>
           <hr>
        </div>
        <!-- End Upgrade Membership ---->


        <!-- Start Message Tabs -->
        <div class="msgtabs mtop30">
            <div class="container-fluid">
                @if(session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="token-amount">
                    <form class="form_inline fullwidth" method="POST" action="{{ route('saveWebsiteSetting') }}">
                        @csrf
    					<div class="form-group row">
                            <label for="token_amount" class="col-md-4 col-form-label text-md-right">Minimum Characters</label>
                            <div class="col-md-6">
                                <input id="min" type="number" class="form-control" name="websiteSettings[screen_name_minimum]" placeholder="" value="{{ $metaData['screen_name_minimum'] or '' }}" required="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="token_amount" class="col-md-4 col-form-label text-md-right">Maximum Characters</label>
                            <div class="col-md-6">
                                <input id="max" type="number" class="form-control" name="websiteSettings[screen_name_maximum]" placeholder="" value="{{ $metaData['screen_name_maximum'] or '' }}" required="">
                            </div>
                        </div>
                        <div class="col-md-10">
                            <button type="submit" class="btnpad btnred pull-right border_radius">Submit</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
</div> 

@endsection
