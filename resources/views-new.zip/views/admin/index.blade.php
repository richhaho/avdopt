@extends('layouts.master')

@section('main-content')
<div class="maincontent">
        <div class="content bgwhite">                       
            
            <!-- Start Upgrade Membership ---->
            <div class="membership">
                <div class="container-fluid">
                   <h4 class="font22 inline_block"><b class="vertical_align"><img src="{{ asset('backend/images/roles.png') }}" alt="Gender" title="Img" class="gender_img">ROLE</b></h4>                 
                           <a href="{{route('admin.create.role')}}" class="btn btnred pull-right">Add Role</a>   
                </div>
                <hr>
            </div>
            <!-- End Upgrade Membership ---->


            <!-- Start Message Tabs -->
            <div class="msgtabs mtop30">
                <div class="container-fluid">
                  <div class="tab-content">
                        <div id="inbox" class="tab-pane fade in active">

                            <table class="table table-striped table-bordered">
                                    <?php $i=1; ?>
                                       <th>Sr.No.</th>
                                        <th>Roles</th>
                                        <th>Action</th>
                          @foreach($role as $row)
                                     <tr>

                                        <td>{{$i++}}</td>
                                        <td>{{$row->role}}</td>
                                        <td><a href="{{route('edit.role',$row->id)}}" class="btn btn-info btn-circle"><i class="fa fa-pencil"></i></a>
            <a href="{{route('role.delete',$row->id)}}" class="btn btn-danger btn-circle"><i class="fa fa-trash-o"></i></button></td>
                                     



                                     </tr>   
                           @endforeach            
                                    
                                   
                                </table>
                              
                            </div>
                                                    
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- End Message Tabs -->

        </div>      
    </div>
@endsection
