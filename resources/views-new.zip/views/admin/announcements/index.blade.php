@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">                       

        <!-- Start Upgrade Membership ---->
        <div class="membership">
            <div class="container-fluid">    
             <h4 class="inline_block font22"><b class="vertical_align"><img src="{{ asset('backend/images/announcement2.png') }}" alt="Img" title="Img" class="announcement">ANNOUNCEMENTS</b></h4>                   
               <a href="{{route('announcement.create')}}" class="btn btnred pull-right">Add Announcement</a>
                </div>
           <hr>
        </div>
        <!-- End Upgrade Membership ---->


        <!-- Start Message Tabs -->
        <div class="announcement_box paddingtb20">
            <div class="container-fluid">
                  
                @if(session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="tab-content">
                    <div id="inbox" class="tab-pane fade in active">
                        <table class="table table-bordered">
                            <tr>
                                <th>#</th>
                                <th>Content</th>
                                <th>Action</th>
                            </tr>
                            @foreach($announcements as $announcement)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $announcement->content }}</td>
                                <td>
                                    <a href="{{route('announcement.edit',$announcement->id)}}" class="btn btn-info btn-circle"><i class="fa fa-pencil"></i></a>
                                    <a onclick="return confirm('Are you sure you want to delete this announcement?')" href="{{route('announcement.delete',$announcement->id)}}" class="btn btn-danger btn-circle"><i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>   
                            @endforeach     
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div> 

@endsection
