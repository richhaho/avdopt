@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">                       

        <!-- Start Upgrade Membership ---->
        <div class="membership">
            <div class="container-fluid">
                    <h4 class="inline_block font22"><b class="vertical_align"><img src="{{ asset('backend/images/taguser.png') }}" alt="Img" title="Img" class="announcement">TOKENS</b></h4>                    
                           <a href="{{route('token.create')}}" class="btn btnred pull-right">Add Token</a>
                </div>
           <hr>
        </div>
        <!-- End Upgrade Membership ---->

        <!-- Start Message Tabs -->
        <div class="msgtabs mtop30">
            <div class="container-fluid">
                @if (session('message'))
                        <div class="alert alert-success">
                            {{ session('message') }}
                        </div>
                    @endif
                <div class="tab-content">
                    <div id="inbox" class="tab-pane fade in active">
                        <table class="table table-bordered">
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Icon</th>
                                <th>Token</th>
                                <th>Discount</th>
                                <th>Additional Text</th>
                                <th>Action</th>
                            </tr>
                            @foreach($tokens as $token)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $token->title }}</td>
                                    <td>{{ $token->description }}</td>
                                    <td> @if($token->icon) <img style="width: 100px;" src="{{ url('uploads/tokenicon/'.$token->icon) }}"> @endif</td>
                                    <td>{{ $token->amount }}</td>
                                    <td>{{ $token->discount }}</td>
                                    <td>{{ $token->additional_text }}</td>
                                    <td>
                                         <a href="{{ route('token.edit', $token->id)}}" class="btn btn-info btn-circle"><i class="fa fa-pencil"></i></a>
                                    <a onclick="return confirm('Are you sure you want to delete token?')" href="{{ route('token.delete', $token->id)}}" class="btn btn-info btn-circle btn-danger" title="Suspend"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                    </td>
                                </tr>
                            @endforeach
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div> 

@endsection
