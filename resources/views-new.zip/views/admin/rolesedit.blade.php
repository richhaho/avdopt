@extends('layouts.master')

@section('main-content')
<div class="maincontent">
        <div class="content bgwhite">                      
            
            <!-- Start Upgrade Membership ---->
            <div class="membership">
                <div class="container-fluid">
                    <h4 class="font22"><i class="fa fa-envelope"></i>Edit Role</h4>
                 </div>
            </div>
            <!-- End Upgrade Membership ---->

            <!-- Start Message Tabs -->
            <div class="msgtabs paddingtb20">
                <div class="container-fluid">
                  <div class="tab-content">
                        <div id="inbox" class="tab-pane fade in active">
                            <form class="form-horizontal" role="form" method="POST" action="{{route('role.update',$role->id)}}">
                                {{ csrf_field() }}
                                <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                    <label for="" class="col-md-4 control-label">Add Role</label>
                                    <div class="col-md-6">
                                        <input id="role"  type="text" class="form-control" name="role" value="{{$role->role}}" required autofocus>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-8 col-md-offset-4">
                                        <button type="submit" class="btn btnred width">
                                            Submit
                                        </button>
                                    </div>
                                </div>
                            </form>
                         </div>                           
                    </div>
                        
                </div>
            </div>
        </div>
            <!-- End Message Tabs -->

        </div>      
    </div>
@endsection
