@extends('layouts.master')

@section('main-content')
<div class="maincontent">
        <div class="content bgwhite">                       
            
            <!-- Start Upgrade Membership ---->
            <div class="membership">
                <div class="container-fluid">
                      <h4 class="inline_block font22"><b><img src="{{ asset('backend/images/genderrole.png') }}" alt="Gender" title="Img" class="gender_img">Gender Role</b></h4>
                   
                        <div class="col-md-10">
                            
                        </div>
                 </div>
            </div>
            <!-- End Upgrade Membership ---->


            <!-- Start Message Tabs -->
            <div class="msgtabs pt50">
                <div class="container-fluid">
                  <div class="tab-content">
                        <div id="inbox" class="tab-pane fade in active">
                            
                            <form class="form-horizontal" role="form" method="POST" action="{{route('gender.update',$gender->id)}}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="title" class="col-md-4 control-label">Title</label>

                            <div class="col-md-6">
                                <input id="title"  type="title" class="form-control" name="title" value="{{$gender->title}}" required autofocus>
                        </div>
                        </div>

                       

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btnred width">
                                    Submit
                                </button>

                                
                            </div>
                        </div>
                    </form>
                              
                         </div>
                            
                            
                          
                          

                            

                        
                        
                                                  
                    </div>
                        
                </div>
            </div>
        </div>
            <!-- End Message Tabs -->

        </div>      
    </div>
@endsection
