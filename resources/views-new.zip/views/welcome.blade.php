@extends('v7.frontend')
<style>
    img.gallery-show {
    height: 310px  !important;
}
span.discover-btn {
    color: #6B02FF;
}
</style>
@section('content')
  <!--begin home section -->
    <section class="home-section" id="home_wrapper">

		<div class="home-section-overlay"></div>

		<!--begin container -->
		<div class="container">

	        <!--begin row -->
	        <div class="row">
	          
	            <!--begin col-md-12-->
	            <div class="col-md-12 text-center">

	          		<h1>Do Not Wait - Launch Your Startup Today!</h1>

	          		<p>Design and style should always work toward making you look good and feel good without<br>
					a lot of efforts so you can get on with the things that truly matters to you.</p>

	        		<a class="popup4 btn-blue" href="https://www.youtube.com/watch?v=FPfQMVf4vwQ">Watch the Demo</a>

	        		<a href="#" class="btn-white">Explore Benefits</a> 

	          </div>
	          <!--end col-md-12-->
	       
	        </div>
	        <!--end row -->

		</div>
		<!--end container -->

    </section>
    <!--end home section -->

    <!--begin sponsors section -->
    <!--<div class="section-grey sponsors-padding">-->
        
        <!--begin container-->
    <!--    <div class="container">-->

            <!--begin row-->
    <!--        <div class="row">-->
            
                <!--begin col-sm-12-->
    <!--            <div class="col-sm-12 sponsors">-->

    <!--                <img src="{{ asset('frontendnew/images/partner2.png')}}" class="sponsor" alt="image">-->

    <!--                <img src="{{ asset('frontendnew/images/partner1.png')}}" class="sponsor" alt="image">-->

    <!--                <img src="{{ asset('frontendnew/images/partner3.png')}}" class="sponsor" alt="image">-->

    <!--                <img src="{{ asset('frontendnew/images/partner4.png')}}" class="sponsor" alt="image">-->

    <!--                <img src="{{ asset('frontendnew/images/partner5.png')}}" class="sponsor" alt="image">-->

    <!--            </div>-->
                <!--end col-sm-12-->
                
    <!--        </div>-->
            <!--end row-->
            
    <!--    </div>-->
        <!--end container-->
    
    <!--</div> -->
    <!--end sponsors section -->

    <!--begin section-white -->
  
    <!--end section-white -->

	<!--begin section-grey -->
    <section class="section-grey" id="about">
        
        <!--begin container-->
        <div class="container">

            <!--begin row-->
            <div class="row">
            
                <!--begin col-md-6-->
                <div class="col-md-6">

                    <div class="youtube-video-wrapper">

                        <!--begin popup-gallery-->
                        <div class="popup-gallery">

                            <a class="popup4 youtube-video-icon" href="https://www.youtube.com/watch?v=FPfQMVf4vwQ">

                            <i class="fa fa-play"></i></a>

                        </div>
                        <!--end popup-gallery-->

                    </div>

                </div>
                <!--end col-sm-6-->
                
                <!--begin col-md-6-->
                <div class="col-md-6">

                	<h3>WE ARE THE <span class="discover-btn">"A"</span> IN ADOPTION</h3>

                	<p>On Avdopt, you're more than just a photo on a prim. You have stories to tell, and things to talk about that are more interesting than lag. Get noticed for who you are, not what you look like. Ditch the panels and the lag; you deserve better!<br><br>

AvDopt is the future of adoption in Second Life! We conveniently avatars to match based on their criteria. Experience quality, convenience, and security at its' finest. Join the revolution of Second Life adoption and find your right match today!</p>
                    
                    <!--<ul class="features-list-dark">-->

                    <!--    <li><i class="fa fa-check lyla"></i> Netsum est, qui ipsum quiaim netsum sequi net tempor.</li>-->

                    <!--    <li><i class="fa fa-check lyla"></i> Etiam tempor ante acu ipsum finibus, atimus urnas.</li>-->

                    <!--    <li><i class="fa fa-check lyla"></i> Atimus urnas netsudat, qui ipsum quiaim netsum.</li>-->

                    <!--    <li><i class="fa fa-check lyla"></i> Etiam tempor ante acum ipsum et finibus.</li>-->

                    <!--</ul>-->

                    <a href="{{route('about')}}" class="btn btn-lg btn-blue">Who We Are</a>
                    
                </div>
                <!--end col-md-6-->
            
            </div>
            <!--end row-->
    
        </div>
        <!--end container-->
    
    </section>
    <!--end section-grey-->

	<!--begin gallery section -->
  	<section class="section-gradient" id="gallery">

		<!--begin container -->
		<div class="container-fluid	">

			<!--begin row -->
			<div class="row">
				
				<!--begin col-md-12 -->
				<div class="col-md-12 text-center">

					<h2 class="section-title white">Recent Members </h2>

					<!--<p class="section-subtitle white">There are many variations of passages of Lorem Ipsum available, but the majority<br>have suffered alteration, by injected humour, or new randomised words.</p>-->
					
				</div>
				<!--end col-md-12 -->

				<!--begin col-md-12 -->
				<div class="gallery-item-wrapper padding-top-30">
                @php
                //$allusers = App\User::where('is_online', 1)->limit(6)->orderBy('id', 'desc')->get();
              // echo"<pre>"; print_r($recentusers); 
                 @endphp
					<!--begin owl carousel -->
					    
					<div id="owl2" class="owl-carousel owl-theme">
           @foreach($recentusers as $singleuser)
					     @php  //echo"<pre>"; print_r($singleuser->name);                  @endphp
					    
             <a href="{{route('viewprofile', base64_encode( $singleuser->id ))}}">
						<img src="{{ asset('/uploads/'.$singleuser->profile_pic)}}" alt="showcase" class="gallery-show">

                          
						</a>
						@endforeach
					</div>
				
					
					
					<!--end owl carousel -->

					<!--begin owl-dots -->
					<div class="owl-dots">

						<div class="owl-dot active"><span></span></div>

						<div class="owl-dot"><span></span></div>

						<div class="owl-dot"><span></span></div>

					</div>
					<!--end owl-dots -->

				</div>
				<!--end col-md-12-->

			</div>
			<!--end row -->

		</div>
		<!--end container -->

	</section>
	<!--end section gallery -->

  	<!--begin team section -->
  
  	<!--end team section -->


  

 

   





    <!--begin blog -->
    <section class="section-grey" id="blog">
        
        <!--begin container-->
        <div class="container">

            <!--begin row-->
            <div class="row margin-bottom-50">
            
                <!--begin col-md-12-->
                <div class="col-md-10 col-md-offset-1 text-center">
                    <h2 class="section-title">Latest Events</h2>
                    
                    <div class="separator_wrapper">
                        <i class="icon icon-star-two blue"></i>
                    </div>
            
                 
                </div>
                <!--end col-md-12-->
            
            </div>
            <!--end row-->
            
            <!--begin row-->
            <div class="row">
                
       @foreach($latesevents as $events)  
       @php
                   
                      $to = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $events->date);
                      $day = date('D', strtotime($to));
                      $dayNumceric = date('d', strtotime($to)); 
                      $month = date('M', strtotime($to)); 
                      $time = date('h:i A', strtotime($events->date));
                    @endphp
                <!--begin col-sm-4 -->
                <div class="col-sm-4">
                    
                    <!--begin blog-item -->
                    <div class="blog-item">
                        
                        <!--begin popup image -->
                        <div class="popup-wrapper">
                            <div class="popup-gallery">
                                <a href="{{ route( 'event.single', $events->id ) }}"><img src="{{ asset('/images/events/'.$events->image)}}" class="width-100" alt="pic"><span class="eye-wrapper2"><i class="icon icon-link eye-icon"></i></span></a>
                            </div>
                        </div>
                        <!--begin popup image -->
                            
                        <!--begin blog-item_inner -->
                        <div class="blog-item-inner">
                        
                            <h3 class="blog-title"><a href="#">{{$events->title}}</a></h3>
                            
                            <a href="#" class="blog-icons"><i class="icon icon-user"></i> {{ $day }}, {{ $month }} {{ $dayNumceric }}</a>
                            
                        
                            
                            <p>{{substr($events->content, 0, 100)}}</p>
                                       
                            <a href="{{ route( 'event.single', $events->id ) }}" class="btn btn-lg btn-blue small">Read More!</a>
                                                   
                        </div>
                        <!--end blog-item-inner -->
                        
                    </div>
                    <!--end blog-item -->
                        
                </div>
                <!--end col-sm-4-->
               @endforeach 
              
             
            </div>
            <!--end row-->
    
        </div>
        <!--end container-->
    
    </section>
    <!--end blog -->
   
  	<!--begin contact -->
    <section class="section-dark" id="contact">
        
        <!--begin container-->
        <div class="container">
    
            <!--begin row-->
            <div class="row">
            
                <!--begin col-md-10 -->
				<div class="col-md-10 col-md-offset-1 text-center margin-bottom-30">

					<h2 class="section-title grey">Get In Touch</h2>

					<p class="section-subtitle grey">There are many variations of passages of Lorem Ipsum available, but the majority<br>have suffered alteration, by injected humour, or new randomised words.</p>
					
				</div>
				<!--end col-md-10 -->

            </div>
            <!--end row-->
            
            <!--begin row-->
            <div class="row margin-20">
        
                <!--begin success message -->
                <p class="contact_success_box" style="display:none;">We received your message and you'll hear from us soon. Thank You!</p>
                <!--end success message -->
                
                <!--begin contact form -->
                <form id="contact-form" class="contact" action="php/contact.php" method="post">
                    
                    <!--begin col-md-6-->
                    <div class="col-md-6">
                        <input class="contact-input white-input" required="" name="contact_names" placeholder="Full Name*" type="text">

                        <input class="contact-input white-input" required="" name="contact_email" placeholder="Email Adress*" type="email">

                        <input class="contact-input white-input" required="" name="contact_phone" placeholder="Phone Number*" type="text">

                    </div>
                    <!--end col-md-6-->
                    
                    <!--begin col-md-6-->
                    <div class="col-md-6">

                        <textarea class="contact-commnent white-input" rows="2" cols="20" name="contact_message" placeholder="Your Message..."></textarea>

                    </div>
                    <!--end col-md-6-->
                    
                    <!--begin col-md-12-->
                    <div class="col-md-12">

                    	<input value="Send Message" id="submit-button" class="contact-submit" type="submit">

                    </div>
                    <!--end col-md-12-->
                    
                </form>
                <!--end contact form -->
            
            </div>
            <!--end row-->
            
      </div>
      <!--end container-->
            
    </section>
    <!--end contact-->
    
    <!--begin footer -->
    <!--<div class="footer">-->
            
        <!--begin container -->
    <!--    <div class="container">-->
        
            <!--begin row -->
    <!--        <div class="row">-->
            
                <!--begin col-md-12 -->
    <!--            <div class="col-md-12 text-center">-->
                   
    <!--                <p>Copyright © 2018 adoption All rights reserved. </p>-->
                                         
                    <!--begin footer_social -->
    <!--                <ul class="footer_social">-->

    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="fa fa-twitter"></i>-->
    <!--                        </a>-->
    <!--                    </li>-->

    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="fa fa-pinterest"></i>-->
    <!--                        </a>-->
    <!--                    </li>-->

    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="fa fa-facebook"></i>-->
    <!--                        </a>-->
    <!--                    </li>-->

    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="fa fa-instagram"></i>-->
    <!--                        </a>-->
    <!--                    </li>-->

    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="fa fa-skype"></i>-->
    <!--                        </a>-->
    <!--                    </li>-->

    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="fa fa-dribble"></i>-->
    <!--                        </a>-->
    <!--                    </li>-->

    <!--                </ul>-->
                    <!--end footer_social -->
                    
    <!--            </div>-->
                <!--end col-md-6 -->
                
    <!--        </div>-->
            <!--end row -->
            
    <!--    </div>-->
        <!--end container -->
                
    <!--</div>-->
    <!--end footer -->
    <!-- End testimonial Section -->
    @endsection