<!DOCTYPE html>
<!--
   This is a starter template page. Use this page to start your new project from
   scratch. This page gets rid of all links and provides the needed markup only.
   -->
<html lang="en">
   <head>
      <title>AVDOPT</title>
      <meta name="csrf-token" content="{{ csrf_token() }}">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" type="text/css" href="{{ asset('frontend/font-awesome/css/font-awesome.min.css') }}">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Bubblegum+Sans|Delius" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/owl.carousel.min.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/bootstrap.min.css') }}">
      <link href="{{ asset('frontendnew/css/bootstrap.css') }}" rel="stylesheet">
      <!-- Loading Template CSS -->
      <link href="{{ asset('frontendnew/css/style.css')}}" rel="stylesheet">
      <link href="{{ asset('frontendnew/css/animate.css')}}" rel="stylesheet">
      <link href="{{ asset('frontendnew/css/style-magnific-popup.css')}}" rel="stylesheet">
      <!-- Fonts -->
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
      <!-- Awsome Fonts -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="{{ asset('frontendnew/css/pe-icon-7-stroke.css')}}">
      <!-- Optional - Adds useful class to manipulate icon font display -->
      <link rel="stylesheet" href="{{ asset('frontendnew/css/helper.css')}}">
      <link rel="stylesheet" href="{{ asset('frontendnew/css/owl.carousel.min.css')}}">
      <link rel="stylesheet" href="{{ asset('frontendnew/css/owl.theme.default.min.css')}}">
      <!-- Font Favicon -->
      <link rel="shortcut icon" href="{{ asset('frontendnew/images/favicon.ico')}}">
      <!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
      <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <![endif]-->
      <script src="{{ asset('frontendnew/js/jquery-1.11.3.min.js')}}"></script>
      <script src="{{ asset('frontendnew/js/bootstrap.js')}}"></script>
      <script src="{{ asset('frontendnew/js/owl.carousel.min.js')}}"></script>
      <script src="{{ asset('frontendnew/js/jquery.scrollTo-min.js')}}"></script>
      <script src="{{ asset('frontendnew/js/jquery.magnific-popup.min.js')}}"></script>
      <script src="{{ asset('frontendnew/js/jquery.nav.js')}}"></script>
      <script src="{{ asset('frontendnew/js/wow.js')}}"></script>
      <script src="{{ asset('frontendnew/js/jquery.vegas.js')}}"></script>
      <script src="{{ asset('frontendnew/js/plugins.js')}}"></script>
      <script src="{{ asset('frontendnew/js/custom.js')}}"></script>
      <script>
         window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
            'url' => url('/'),
            ]); ?>
      </script>
      @yield('head')
      <link rel="stylesheet" type="text/css" href="{{ asset('frontendnew/css/style.css') }}">
      <!--<link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/style.css') }}">-->
      <!-- BEGIN PAGE LEVEL STYLES -->
      @yield('page_level_styles')
      <!-- END PAGE LEVEL STYLES -->
      <style>
        div#bs-example-navbar-collapse-1 {
        margin-top: 13px;
        }
        ul.myfun_list {
    padding: 14px;
}
         .header {
         padding: 0 !important;
         height: auto !important;
         }
         .footer_sec ul {
         border-left: 2px solid #ffe5e5;
         }
         .footer_sec ul li a {
         color: #fff;
         font-weight: 400;
         padding-left: 1rem;
         }
         .footer_sec {
         background: #272727;
         padding: 15px 0;
         }
         .foot_dv img {
         width: 100%;
         max-width: 100px;
         }
         .footer_sec::after {
         border-top: 2px solid #fff;
         display: block;
         height: 1px;
         content: " ";
         width: 86%;
         position: absolute;
         left: 91px;
         }
         .foot_dv p {
         color: #fff;
         text-align: left;
         margin-top: 10px;
         padding-left: 0;
         }
         .footer_sec ul {
         border-left: 1px solid #ffe5e5;
         height: 124px;
         }
         .footer_sec ul li a {
         color: #fff;
         font-weight: 400;
         padding-left: 1rem;
         font-size: 16px;
         }
         /*---- Header ----*/
         .form_sec input {
         width: 20%;
         display: inline-block;
         }
         .top_header {
         background: #3b5998;
         padding: 10px;
         padding-right: 9rem;
         }
         .form_sec input {
         width: 10%;
         display: inline-block;
         }
         .form_sec {
         text-align: right;
         width: 100%;
         }
         button.btnpad.btnred.border0.sb_btn {
         background: linear-gradient(135deg, #6B02FF 0%, #985BEF 100%);
         border-radius: 5px 5px;
         padding: 8px 25px!important;
         margin-left: 10px;
         margin-right: 15px;
         font-family: 'Roboto', sans-serif;
         color: #fff;
         outline: none;
         border: none;
         }
         .gl_btn{
         color: #fff;
         font-size: 14px !important;
         text-transform: uppercase;
         font-family: 'Roboto', sans-serif;
         font-weight: 600;
         margin:5px;
         }
         .gl_btn:hover{color:#fff;}
         nav.navbar.navbar-default.navbar-fixed-top.opaque {
         margin-top: 0;
         }
         a.gl_btn img {
         padding-right: 5px;
         }
         .navbar {
         margin-top: 49px;
         }
         .navbar-header a img {
         width: 100%;
         max-width: 154px;
         }
         a.btn.reg_btn {
         background: transparent;
         border: 1px solid #fff;
         border-radius: 5px 5px;
         padding: 7px 18px!important;
         margin-left: 10px;
         margin-right: 15px;
         font-family: 'Roboto', sans-serif;
         color: #fff;
         }
         a.btn.reg_btn:hover {color: #4285f4!important;
         background: #ffffff;}
      </style>
   </head>
   <body>
      <!-- Start Top Header -->
      <header class="header">
         <div class="top_header">
            <div class="form_sec">
               @if (Auth::check()) 
               <a class="gl_btn " href="{{route('admin.dashboard')}}"><img src="{{ asset('frontend/images/login.png') }}" alt="account" title="account">My Account</a>
               <a class="gl_btn " href="{{ route('logout') }}"
                  onclick="event.preventDefault();
                  document.getElementById('logout-form').submit();">
               {{ __('Logout') }}
               </a>
               <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                  @csrf
               </form>
               @else
               <form method="POST" action="{{ route('login') }}">
                  @csrf
                  <input id="email" type="text" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required autofocus>
                  <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>
                  @if ($errors->has('password'))
                  <span class="invalid-feedback">
                  <strong>{{ $errors->first('password') }}</strong>
                  </span>
                  @endif
                  <button type="submit" class="btnpad btnred border0 sb_btn">
                  {{ __('Login') }}
                  </button>
                  <a class="btn reg_btn" href="http://laravel.avdopt.com/register">Register</a>
               </form>
               @endif
            </div>
         </div>
         <nav class="navbar navbar-default navbar-fixed-top">
            <!--begin container -->
            <div class="container">
               <!--begin navbar -->
               <div class="navbar-header">
                  <button data-target="#navbar-collapse-02" data-toggle="collapse" class="navbar-toggle" type="button">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  </button>
                  <!--logo -->
                  <a href="{{url('/')}}"><img src="{{ asset('frontend/images/logo.png') }}" alt="mail" title="mail"></a>
               </div>
               <!--<div class="collapse navbar-collapse padding0" id="bs-example-navbar-collapse-1">        -->
               <div id="bs-example-navbar-collapse-1" class="collapse navbar-collapse padding0">
                  <ul class="nav navbar-nav navbar-right">
                     <li><a href="{{url('/')}}">Home</a></li>
                     <li><a href="{{ url('/events') }}">Events</a></li>
                     <li><a href="{{ url('/browse') }}">Browse</a></li>       
                     <li><a href="{{ url('') }}#about">About</a></li>
                     <!--<li><a href="#services">Services</a></li>-->
                     <!--<li><a href="#features">Features</a></li>-->
                     <!--<li><a href="#pricing">Pricing</a></li>-->
                     <!--<li><a href="#blog">Blog</a></li>-->
                     <li><a href="#contact" class="discover-btn">Get Started</a></li>
                  </ul>
                  <!--<ul class="nav navbar-nav navbar-right">-->
                  <!--            <li class="active"><a href="{{url('/')}}">HOME <span class="sr-only"></span></a></li>-->
                  <!--            <li><a href="{{url('/browse')}}">BROWSE</a></li>-->
                  <!--            <li><a href="{{url('/jobs')}}">JOBS</a></li>-->
                  <!--            <li><a href="#">HOW IT WORKS</a>-->
                  <!--            </li>-->
                  <!--            <li><a href="#">CONTACT US</a></li>-->
                  <!--            <li><a href="{{ url('/events') }}">EVENTS</a></li>-->
                  <!--        </ul>-->
               </div>
               <!--end navbar -->
            </div>
            <!--end container -->
         </nav>
      </header>
      <!-- End Top Header -->
      @yield('content')
      <div class="footer_sec">
         <div class="container">
            <div class="row">
               <div class="col-md-3">
                  <div class="foot_dv">
                     <a href="{{url('/')}}"><img src="{{ asset('frontend/images/logo_footer.png') }}" alt="mail" title="mail"></a>
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Ut enim ad minim veniam,</p>
                  </div>
               </div>
               <div class="col-md-3">
                  <ul>
                     <li><a href="">About us</a></li>
                     <li><a href="">How it works</a></li>
                     <li><a href="">In-world Office</a></li>
                     <li><a href="">Careers</a></li>
                  </ul>
               </div>
               <div class="col-md-3">
                  <ul>
                     <li><a href="">Terms</a> </li>
                     <li><a href="">Policy</a></li>
                     <li><a href="">Help Center</a></li>
                  </ul>
               </div>
               <div class="col-md-3">
                  <ul>
                     <li><a href="">Register</a></li>
                     <li><a href="">Browse</a></li>
                     <li><a href="">Events</a></li>
                     <li><a href="">Blog</a></li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="row">
            <!--begin col-md-12 -->
            <div class="col-md-12 text-center">
               <p>Copyright © 2018 adoption All rights reserved. </p>
            </div>
         </div>
      </div>
      @yield('scripts')
      <!-- BEGIN PAGE LEVEL SCRIPTS -->
      @yield('page_level_scripts')
      <!-- END PAGE LEVEL SCRIPTS -->
   </body>
</html>