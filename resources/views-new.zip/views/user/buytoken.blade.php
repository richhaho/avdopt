@extends('layouts.master')
@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">
        <div class="buy_tokens">
            <div class="container-fluid">
                <div style="float: left;width: 100%;">
                <h4 style="float:left" class="font22"><b class="vertical_align"> <img src="{{ asset('backend/images/token_bundle.png') }}" alt="bundle Img" title="Img">TOKEN BUNDLES</b></h4><a href="{{ route('payment.credit') }}" class="btn btnred pull-right">Add Manually</a>
                </div>
                <hr>
                <div class="mtop20 text-center">
                    <span>Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do </span>
                    <span> eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
                </div>
                <div class="width80 text-center">
                    <h2 class="mtopbottom20"><b>Top Up Tokens</b></h2>
                    <div class="col-md-12 mtop20 pb80">
                        @if($tokens)
                            @php
                                $tokenamount = getWebsiteSettingsByKey('token_amount');
                            @endphp
                        	@foreach($tokens as $token)
                        		<div class="col-md-6 col-sm-6 col-xs-12 mb40">
                        			<div class="bordertoken">
                        				<!-- Heading -->
                        				<h2 class=""><b>{{ title_case( $token->title ) }}</b></h2>
                        				<!-- Content -->
                        				<div class="tokens">
                        					<div class="col-md-4 col-sm-4 col-xs-12">
                        						<img alt="bundle Img" title="Img" src="{{ url('uploads/tokenicon/'.$token->icon) }}">
                        					</div>
                        					<div class="col-md-8 col-sm-8 col-xs-12">
                        						<p>{{ $token->description }}</p>
                        					</div>
                        					<div class="col-md-6 col-sm-6 col-xs-12">
                        					    <form class="form-horizontal " role="form" method="POST" action="{{ route('token.purchase')}}">
                                                    @csrf
                                                    @php
                                                        $discount = $newamount = 0;
                                                        $amount = ( $tokenamount )? $token->amount * ( $tokenamount ): $token->amount;
                                                        if( $token->discount ){
                                                            $discount = ( $amount * $token->discount )/100;
                                                            if( $discount ){
                                                                $amount = $amount - $discount;
                                                            } 
                                                        }
                                                        $newamount = $amount * 100;
                                                    @endphp
                                                    <button type="submit" class="mtop10 mb"><span>Buy</span></button>
                                                    <input type="hidden" name="chargeId" value="{{ $token->id }}" >
                                                    <div class="hidescript">
                                                        <script
                                                            src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                                            data-key="{{ env('STRIPE_KEY') }}"
                                                            data-amount="{{ $newamount }}"
                                                            data-name="{{ $token->title }}"
                                                            data-description="{{ $token->description }}"
                                                            data-image="{{url('/')}}/backend/images/logo.jpg"
                                                            data-locale="auto">
                                                        </script>
                                                    </div>
                                                </form>
                        					</div>
                        				</div>
                        				<!-- Button -->
                        				<div class="col-md-12 col-sm-12 col-xs-12">
                        				    @if($token->additional_text)
                        					    <button type="sumit" class="mostpopular">{{ $token->additional_text }}</button>
                        					@endif
                        				</div>
                        			</div>
                        		</div>
                        	@endforeach
                        @endif
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>  
        </div>
    </div>
</div>
@endsection