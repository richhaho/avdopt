@extends('layouts.master')

@section('main-content')
 <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor"><img class=" all_users" alt=" Img" src="/backend/images/mylike.png"> My Likes</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">My Likes</li>
                    </ol>
                </div>
                <div>
                    <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button>
                </div>
            </div>
<!-- Start Main Content ---->
  <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">                     

        <!-- Start Upgrade Membership ---->

        @if ( !isthisSubscribed() )
            <div class="row mtop30 upgrade">
    			<div class="col-md-10">
    				<div class="upgdinfo bggray font300">
    					<p>Hey {{ ucfirst( Auth::user()->name ) }}!. Upgrade your membership today to check your likes.</p>
    				</div>
    			</div>
    			<div class="col-md-2">							
        			<a style="padding: 18px 0px;" href="{{ url('pricing') }}" class="btn btnred width100">Upgrade Membership</a>
    			</div>
    		</div>
    	@endif
        <!-- End Upgrade Membership ---->
        <!-- Start Match Tabs -->
        @if ( isthisSubscribed() )
            <div class="myliketab mtop30 pt30">
                <div class="container-fluid">
                    <div class="row">
                    <div class="col-md-12 mb30">
                        @if( $likes )
                            @foreach( $likes as $userid )
                                @php
                                    $userdata = \App\User::find($userid);
                                    $profilepic = ( @$userdata->profile_pic )? 'uploads/'.$userdata->profile_pic : 'images/default.png';
                                @endphp
                                @if( $userdata )
                                <div class="el-element-overlay">
                                    
                                <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="el-card-item">
                                <div class="el-card-avatar el-overlay-1"> <img src="{{ asset($profilepic) }}" /> @if( $userdata->is_online )
                                        <span class="green"></span>
                                    @endif
                                    <div class="el-overlay scrl-dwn">
                                        <ul class="el-info">
                                            <li><a class="btn default btn-outline image-popup-vertical-fit" href="{{ asset($profilepic) }}"><i class="icon-magnifier"></i></a></li>
                                            <li><a class="btn default btn-outline" href="{{route('viewprofile', base64_encode( $userid ))}}"><i class="icon-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="el-card-content">
                                    <h3 class="box-title">{{ ucfirst( $userdata->name ) }}</h3> <small>{{ @$userdata->usergroup->title }}</small>
                                    <br/> </div>
                            </div>
                        </div>
                    </div>
                   
                    </div>
                              
                                @endif
                            @endforeach
                        @endif
                    </div>   
                    </div>
                </div>
            </div>
        @endif
        <!-- End Match Tabs -->

   </div>
                        </div>
                    </div>
                </div>
                 </div>
<!-- End Main Content ---->
@endsection