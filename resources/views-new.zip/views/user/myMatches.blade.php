@extends('layouts.master')

@section('main-content')
<!-- Start Main Content ---->
                     

        <!-- Start Upgrade Membership ---->
        <!--<div class="membership">-->
        <!--    <div class="container-fluid">-->
        <!--        <h4 class="font22"><b class="vertical_align"><img src="{{ asset('backend/images/mymatch.png') }}" alt="" class="all_users"><span>MY MATCHES</span></b></h4>-->
        <!--    </div>-->
        <!--</div>-->
        <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor"><img src="{{ asset('backend/images/mymatch.png') }}" alt="" class="all_users"> My Matches</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">My Hatches</li>
                    </ol>
                </div>
                <div>
                    <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button>
                </div>
            </div>

        @if ( !isthisSubscribed() && !getmanualfeatures('token_view_my_matches_'))
            @include('includes.debitTokens', ['featurevalue'=>'token_monthly_connection_value_','featureclass'=>'chat','featurename'=>'token_view_my_matches_', 'featureMessage'=>'Hey '. ucfirst( Auth::user()->name ) .'!. Upgrade your membership today to experience unlimited chat.'])
    	@endif
        <!-- End Upgrade Membership ---->
        <!-- Start Match Tabs -->
  <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body"> 
                <div class="col-md-12">
                    @if ( isthisSubscribed() || getmanualfeatures('token_view_my_matches_'))
                        @if( $matches )
                            @foreach( $matches as $match )
                                 @php
                                    $userid = $match->user_id;
                                    if( $match->user_id == Auth::user()->id ){
                                        $userid = $match->matcher_id;
                                    }
                                    $userdata = \App\User::find($userid);
                                    $profilepic = (@$userdata->profile_pic )? 'uploads/'.$userdata->profile_pic : 'images/default.png';
                                @endphp
                                @if( $userdata )
                                <div class="el-element-overlay">
                                    <div class="row">
                                  <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="el-card-item">
                                <div class="el-card-avatar el-overlay-1"> <img src="{{ asset($profilepic) }}" /> @if( $userdata->is_online )
                                        <span class="green"></span>
                                    @endif
                                    <div class="el-overlay scrl-dwn">
                                        <ul class="el-info">
                                            <li><a class="btn default btn-outline image-popup-vertical-fit" href="{{ asset($profilepic) }}"><i class="icon-magnifier"></i></a></li>
                                            <li><a class="btn default btn-outline" href="{{route('viewprofile', base64_encode( $userid ))}}"><i class="icon-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="el-card-content">
                                    <h3 class="box-title">{{ ucfirst( $userdata->name ) }}</h3> <small>{{ @$userdata->usergroup->title }}</small>
                                    <br/> </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    </div>

                                @endif
                            @endforeach
                        @endif
                    @endif

   </div>
                        </div>
                    </div>
                </div>
                 </div>
        <!-- End Match Tabs -->

<script>
    $(document).ready(function(){
        $(".matches").click(function(){
            $('#trialid').val($(this).attr('table-id'));
            var userid = $(this).data('user');
            var imgSrc = $(this).find('img').attr('src');
            var href = $(this).find('a').attr('href');
            var popup = $("#myModal");
            popup.find("#macher_id").val(userid);
            popup.find(".macher_image").attr("src", imgSrc);
            popup.find(".matcher_name").text(href);
        });
    });
</script>
<!-- End Main Content ---->
@endsection
@section('footer')
    @include('modals/trials-modals')
@endsection