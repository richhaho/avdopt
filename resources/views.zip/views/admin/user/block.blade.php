@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite"> 
        <!-- Start Message Tabs -->
        <div class="Report_box paddingtb10">
            <div class="container-fluid">
                 <h4 class="font22"><b class="vertical_align"><img src="{{ asset('backend/images/report.png') }}" alt="Report" title="Img">REPORTS</b></h4>
                 <hr>
                @if(session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                @php
                @endphp
                <div class="tab-content mtop30">
                    <div id="inbox" class="tab-pane fade in active">
                        <table class="table table-bordered">
                            <th>#</th>
                            <th>User ID</th>
                            <th>Reported ID</th>
                            <th>Reason</th>
                            <th>Description</th>
                            @foreach ($blockusers as $blockuser)
                                @php
                                    $blockedbyinfo = App\User::find($blockuser->user_id);
                                    $blockeduserinfo = App\User::find($blockuser->block_id);
                                @endphp
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ @$blockedbyinfo->name }}</td>
                                <td>{{ @$blockeduserinfo->name }}</td>
                                <td>{{ $blockuser->reason }}</td>
                                <td>{{ $blockuser->description }}</td>
                            </tr>       
                            @endforeach
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div> 

@endsection
