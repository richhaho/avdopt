@extends('layouts.master')

@section('main-content')
<div class="maincontent">
        <div class="content bgwhite">                       
            
            <!-- Start Upgrade Membership ---->
            <div class="membership">
                <div class="container-fluid">
        <h4 class="inline_block font22"><b><img src="{{ asset('backend/images/questionnaries2.png') }}" alt="Img" title="Img" class="announcement">Questionnaires</b></h4>                  
                    <a href="{{route('questionnaires.create', $groupId )}}" class="btn btnred pull-right">Add Questionnaires</a>
                    <a href="{{route('admin.usergroup')}}" class="btn btnred pull-right">Back To User Groups</a>
                </div>
                 <hr>
            </div>
            <!-- End Upgrade Membership ---->


            <!-- Start Message Tabs -->
            <div class="msgtabs pt50">
                <div class="container-fluid">
                  <div class="tab-content">
                        <div id="inbox" class="tab-pane fade in active">

                            <table class="table table-striped table-bordered">
                                       <th>Sr.No.</th>
                                       <th>Title</th>
                                        <th>User Group</th>
                                        <th>Action</th>
                                            @foreach ($questionnaires as $questionnairy)
                                                <tr>
                                                    <td>{{ $loop->iteration }}</td>
                                                    <td>{{ $questionnairy->question_title }}</td>
                                                    <td>
                                                    @php
                                                    $groupInfo = array();
                                                    $groupids = explode(',',$questionnairy->group_id);
                                                    
                                                    if( $groupids ){
                                                        foreach( $groupids as $groupid ){
                                                        
                                                        $title = App\Usergroup::find($groupid);
                                                            if($title){
                                                               $groupInfo[] = @$title->title;
                                                            }
                                                        }
                                                            echo implode(', ', $groupInfo);
                                                    }
                                                @endphp
                                                    </td>
                                                    <td>
                                                       <a href="{{route('question.edit',$questionnairy->id)}}" class="btn btn-info btn-circle  border0"><i class="fa fa-edit"></i></a>
                                                       <a href="{{route('question.destroy',$questionnairy->id)}}" onclick="return confirm('Are you sure you want to delete this Questionnary?')"; class="btn btn-info btn-circle btn-danger border0"><i class="fa fa-trash"></i></button>
                                                    </td>
                                                 </tr>   
                                            @endforeach
                                     
                          {{ $questionnaires->links() }}
                                </table>
                              
                            </div>
                            
                                                     
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- End Message Tabs -->

        </div>      
    </div>
@endsection
