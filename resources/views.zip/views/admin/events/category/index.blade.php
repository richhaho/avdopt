@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">                       

        <!-- Start Upgrade Membership ---->
        <div class="membership">
            <div class="container-fluid">
                    <h4 class="inline_block font22"><b><img src="{{ asset('backend/images/taguser.png') }}" alt="Img" title="Img" class="announcement">Event Categories</b></h4>                    
                           <a href="{{route('event.category.create')}}" class="btn btnred pull-right">Add Category</a>
                </div>
           <hr>
        </div>
        <!-- End Upgrade Membership ---->


        <!-- Start Message Tabs -->
        <div class="msgtabs pt50">
            <div class="container-fluid">
                @if(session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="tab-content">
                    <div id="inbox" class="tab-pane fade in active">
                        <table class="table table-bordered">
                            <th>#</th>
                            <th>Title</th>
                            <th>Action</th>
                            @foreach($categories as $category)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{$category->term_name}}</td>
                                <td>
                                    <a href="{{ route('event.category.edit', $category->id)}}" class="btn btn-info btn-circle"><i class="fa fa-pencil"></i></a>
                                    <a onclick="return confirm('Are you sure you want to delete tag?')" href="{{ route('event.category.delete', $category->id)}}" class="btn btn-info btn-circle btn-danger" title="Suspend"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                 </td>
                            </tr>   
                            @endforeach     
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div> 

@endsection
