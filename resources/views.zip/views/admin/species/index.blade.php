@extends('layouts.master')
@section('main-content')
    <div class="maincontent">
        <div class="content bgwhite">
            <!-- Start Upgrade Membership ---->
            <div class="membership">
                <div class="container-fluid">
                    <h4 class="font22 inline_block">
                       <b class="vertical_align">
                           <img src="{{ asset('backend/images/user.png') }}" alt="Species" title="Img" class="gender_img">
                           Species
                       </b>
                    </h4>
                    <a href="{{route('admin.species.create')}}" class="btn btnred pull-right">Add Species</a>
                </div>
                <hr>
            </div>
            <!-- End Upgrade Membership ---->
            <!-- Start Message Tabs -->
            <div class="msgtabs mtop30">
                <div class="container-fluid">
                    <div class="tab-content">
                        <div id="inbox" class="tab-pane fade in active">
                            @if (session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                            @endif
                            @if (session('warning'))
                                <div class="alert alert-warning">
                                    {{ session('warning') }}
                                </div>
                            @endif
                            <table class="table table-striped table-bordered">
                                <tr>
                                    <?php $i=1; ?>
                                    <th>Sr.No.</th>
                                    <th>Species Name</th>
                                    <th>Action</th>
                                </tr>
                                @if(count($species))
                                @foreach($species as $row)
                                <tr>
                                    <td>{{$i++}}</td>
                                    <td>{{$row->name}}</td>
                                    <td>
                                        <a href="{{route('admin.species.edit',$row->id)}}" class="btn btn-info btn-circle"><i class="fa fa-pencil"></i></a>
                                        <a href="javascript:void(0);" onclick="deleteItem({{$row->id}},'{{route('admin.species.delete',$row->id)}}')"
                                           class="btn btn-danger btn-circle">
                                            <i class="fa fa-trash-o"></i>
                                        </a>
                                    </td>
                                </tr>
                                @endforeach
                                @else
                                <tr>
                                    <td colspan="10" class="text-center text-danger">No record found</td>
                                </tr>
                                @endif
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Message Tabs -->
        </div>
    </div>
@endsection
