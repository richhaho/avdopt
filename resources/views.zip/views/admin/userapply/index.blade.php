@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">                       

        <!-- Start Upgrade Membership ---->
        <div class="membership">
            <div class="container-fluid">
                    <h4 class="inline_block font22"><b class="vertical_align"><img src="{{ asset('backend/images/applicants2.png') }}" alt="Img" title="Img" class="announcement">ALL APPLICANTS</b></h4>
                </div>
           <hr>
        </div>
        <!-- End Upgrade Membership ---->


        <!-- Start Message Tabs -->
        <div class="msgtabs mtop30">
            <div class="container-fluid">
                @if(session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="tab-content">
                    <div id="inbox" class="tab-pane fade in active">
                        <table class="table table-bordered">
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Contact No.</th>
                                <th>Email</th>
                                <th>Resume</th>
                                <th>Action</th>
                            </tr>
                            @foreach($alldata as $data)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $data->name }}</td>
                                <td>{{ $data->contact_no }}</td>
                                <td>{{ $data->email }}</td>
                                <td>
                                    @if($data->file) 
                                        @php
                                           $path = asset("uploads/resumes/$data->file")
                                        @endphp
                                        <a href="{{ $path }}" class="btn btn-info btn-circle" target="_blank"><i class="fa fa-download" aria-hidden="true"></i></a>
                                    @endif
                                </td>
                                <td><a onclick="return confirm('Are you sure you want to delete this application?')" href="{{ route('delete.applicant',$data->id) }}" class="btn btn-danger btn-circle"><i class="fa fa-trash-o"></i></a></td>

                            </tr>    
                            @endforeach
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div> 
@endsection
