@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">                       

        <!-- Start Upgrade Membership ---->
        <div class="membership">
            <div class="container-fluid">
                    <h4 class="inline_block font22"><b><img src="{{ asset('backend/images/taguser.png') }}" alt="Img" title="Img" class="announcement">Emails</b></h4>                    
                     
                </div>
           <hr>
        </div>
        <!-- End Upgrade Membership ---->


        <!-- Start Message Tabs -->
        <div class="msgtabs pt50">
            <div class="container-fluid">
                @if(session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="tab-content">
                    <div id="inbox" class="tab-pane fade in active">
                        <table class="table table-bordered">
                            <tr>
								<th>#</th>
								<th>Email</th>
								<th>Action</th>
							</tr>
                            	@foreach($emails as $email)
									<tr>
										<td>{{ $loop->iteration }}</td>
										<td>{{ @$email->subject }}</td>
										<td>
											<a href="{{ route('edit.email.notify', $email->id) }}" class="btn btn-info btn-circle"><i class="fa fa-pencil"></i></a>
										</td>
									</tr>
								@endforeach
                            
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div> 

@endsection
