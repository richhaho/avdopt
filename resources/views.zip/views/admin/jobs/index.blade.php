@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">                       

        <!-- Start Upgrade Membership ---->
        <div class="membership">
            <div class="container-fluid">
              <h4 class="inline_block font22"><b class="vertical_align"><img src="{{ asset('backend/images/job2.png') }}" alt="Img" title="Img" class="announcement">JOBS</b></h4>
                    <a href="{{route('create.jobs')}}" class="btn btnred pull-right">Add job</a>
                </div>
           <hr>
        </div>
        <!-- End Upgrade Membership ---->


        <!-- Start Message Tabs -->
        <div class="msgtabs mtop30">
            <div class="container-fluid">
                @if(session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="tab-content">
                    <div id="inbox" class="tab-pane fade in active">
                        <table class="table table-bordered">
                            <th>#</th>
                            <th>Title</th>
                            <th>Company Name</th>
                            <th>Location</th>
                            <th>Job Type</th>
                            <th>Salary</th>
                            <th>tags</th>
                            <th>Action</th>
                            @foreach($jobs as $job)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{$job->title}}</td>
                                <td>{{$job->company_name}}</td>
                                <td><a target="_blank" href="{{ $job->location }}"> {{$job->location}}</a></td>
                                <td>{{$job->job_type}}</td>
                                <td>{{$job->salary}}</td>
                                <td>
                                    @php
      
                                        $getjobs = ( $job->tag_title )? json_decode( $job->tag_title ) : array();
                                        echo implode(', ', $getjobs);
                                    @endphp    
                                </td>
                                <td>
                                    <a href="{{ route('edit.jobs', $job->id)}}" class="btn btn-info btn-circle"><i class="fa fa-pencil"></i></a>
                                    <a onclick="return confirm('Are you sure you want to delete job?')" href="{{ route('delete.jobs', $job->id)}}" class="btn btn-info btn-circle btn-danger" title="Suspend"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                 </td>
                            </tr>   
                            @endforeach     
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div> 

@endsection
