@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">                       

        <!-- Start Upgrade Membership ---->
        <div class="membership">
            <div class="container-fluid">
                <h3><i class="fa fa-envelope"></i>User Group</h3>

                <div class="col-md-10"> </div>
            </div>
        </div>
        <!-- End Upgrade Membership ---->


        <!-- Start Message Tabs -->
        <div class="msgtabs pt50">
            <div class="container-fluid">
                <div class="tab-content">
                    <div id="inbox" class="tab-pane fade in active">

                        <form class="form-horizontal" role="form" method="POST" action="{{route('usergroup.update',$usergroup->id)}}">
                            {{ csrf_field() }}

                            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                <label for="title" class="col-md-4 control-label">Title</label>

                                <div class="col-md-6">
                                    <input id="title"  type="title" class="form-control" name="title" value="{{ $usergroup->title }}" required autofocus>
                                    @if ($errors->has('title'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('title') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                <label for="minage" class="col-md-4 control-label">Age(Min.)</label>

                                <div class="col-md-6">
                                    <input id="minage"  type="number" class="form-control" name="minage" value="{{ $usergroup->minage }}" required autofocus>
                                    @if ($errors->has('minage'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('minage') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                <label for="maxage" class="col-md-4 control-label">Age(Max.)</label>

                                <div class="col-md-6">
                                    <input id="maxage"  type="number" class="form-control" name="maxage" value="{{ $usergroup->maxage }}" required autofocus>
                                </div>
                                @if ($errors->has('maxage'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('maxage') }}</strong>
                                    </span>
                                @endif
                            </div>

                            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                <label for="role" class="col-md-4 control-label">Gender role</label>

                                <div class="col-md-6">
                                    <select class="form-control searchdropdown" multiple id="role" name="gender[]" required="required">
                                    @foreach($role as $row)
                                        @php
                                            $sel = '';
                                            $getgenderrole = ($usergroup->genderrole)? json_decode( $usergroup->genderrole ) : array();
                                            if( in_array($row->id, $getgenderrole) ){
                                                $sel = "selected='selected'";
                                            }
                                        @endphp
                                        <option {{ $sel }} value="{{ $row->id }}" ><?php echo $row->title ?></option>
                                    @endforeach
                                    @if ($errors->has('gender'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('gender') }}</strong>
                                        </span>
                                    @endif
                                </select>
                            </div>
                        </div>
                        <div class="form-group{{ $errors->has('plans') ? ' has-error' : '' }}">
                             <label for="Plan" class="col-md-4 control-label">MemberShip Plan</label>
                                <div class="col-md-6">
                                <select class="form-control searchdropdown" id="plans" name="plans[]" multiple>
                                    @foreach($plans as $row)
                                        @php
                                            $sel = '';
                                            $getplans = ($usergroup->membership_plans)? json_decode( $usergroup->membership_plans ) : array();
                                            if( in_array($row->id, $getplans) ){
                                                $sel = "selected='selected'";
                                            }
                                        @endphp
                                        <option {{ $sel }} value="{{ $row->id }}" ><?php echo $row->name ?></option>
                                    @endforeach
                                </select>
                           </div>
                        </div>
                        <div class="form-group{{ $errors->has('tags') ? ' has-error' : '' }}">
                                <label for="maxage" class="col-md-4 control-label">Group Tag</label>

                                <div class="col-md-6">
                                    <select name="tags" class="form-control">
                                    @foreach($usergroupstags as $usergroupstag)
                                        <option @if($usergroup->tags == $usergroupstag->id) selected @endif value="{{ $usergroupstag->id }}">{{ $usergroupstag->title }}</option>
                                    @endforeach
                                </select>
                                </div>
                                @if ($errors->has('tags'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('tags') }}</strong>
                                    </span>
                                @endif
                            </div>

                        
                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btnred width">
                                    Submit
                                </button>
                            </div>
                        </div>
                    </form>

                </div>


            </div>

        </div>
    </div>
</div>
<!-- End Message Tabs -->

</div> 
@endsection

@section('footer')
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.searchdropdown').select2({
            placeholder: 'select role',
          multiple: true
        });
    });
</script>
@endsection
