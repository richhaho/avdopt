@extends('layouts.master')

@section('main-content')
<div class="maincontent">
        <div class="content bgwhite">  
            <!-- Start Message Tabs -->
            <div class="addrole_box paddingtb20">
                <div class="container-fluid">
                    <h4 class="font22"><b class="vertical_align"><img src="{{ asset('backend/images/roles.png') }}" alt="Gender" title="Img" class="gender_img">Role</b></h4>
                  <div class="tab-content paddingtb20">
                        <div id="inbox" class="tab-pane fade in active">
                            <form class="form-horizontal" role="form" method="POST" action="{{route('role.store')}}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="" class="col-md-4 control-label">Add Role</label>
                            <div class="col-md-6">
                                <input id="role"  type="text" class="form-control" name="role" value="{{ old('heading') }}" required autofocus>
                        </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btnred width">
                                    Submit
                                </button>

                                
                            </div>
                        </div>
                    </form>
                              
                         </div>                           
                    </div>
                        
                </div>
            </div>
        </div>
            <!-- End Message Tabs -->

        </div>      
    </div>
@endsection
