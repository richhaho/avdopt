@extends('layouts.frontend')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Security Pin') }}       @if (session('status'))
                    <div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                    @endif
                    @if (session('warning'))
                    <div class="alert alert-warning">
                        {{ session('warning') }}
                    </div>
                    @endif
                </div>

                <div class="card-body">
                    <form method="POST" action="{{ route('password.store') }}">
                        @csrf
                        
                        <div class="form-group row">

                            <label for="pin" class="col-sm-4 col-form-label text-md-right">{{ __('Enter Security Pin') }}</label>

                            <div class="col-md-6">
                                <input id="pin" type="text" class="form-control{{ $errors->has('pin') ? ' is-invalid' : '' }}" name="pin"  placeholder="Enter 4-digit Pin For security" value="{{ old('pin') }}" required autofocus>

                                @if ($errors->has('pin'))
                                <span class="invalid-feedback">
                                    <strong>{{ $errors->first('pin') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Submit') }}
                                </button>


                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection