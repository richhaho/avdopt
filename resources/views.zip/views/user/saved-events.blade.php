@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">

        <!-- Start Upgrade Membership ---->
        <div class="membership">
            <div class="container-fluid">
                    <h4 class="inline_block font22"><b><img src="{{ asset('backend/images/taguser.png') }}" alt="Img" title="Img"  class="announcement">Saved Events</b></h4>
                </div>
           <hr>
        </div>
        <!-- End Upgrade Membership ---->
        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif
        <!-- Start Message Tabs -->
        <div class="msgtabs pt30">
            <div class="container-fluid">
                @if(session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="tab-content">
                    <div id="inbox" class="tab-pane fade in active">
                        <table class="table table-bordered">
                            <th>#</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Date</th>
                            <th width="15%">Location</th>
                            <th width="10%">Action</th>
                            @if(count($saved_events)>0)
                            @foreach($saved_events as $event)
                            <tr>
                                <td>{{$loop->iteration}}</td>
                                <td><a target="_blank" class="" href="{{ route('event.single', $event->id)}}">{{$event->title}}</a></td>
                                <td>
                                    @if($event->category)
                                        @php
                                            $name = array();
                                            $ids = json_decode($event->category);
                                            if($ids){
                                                $allCats = \App\EventCategory::find($ids);
                                                if($allCats){
                                                    foreach($allCats as $cat){
                                                        $name[] = $cat->term_name;
                                                    }
                                                    echo implode(', ',$name);
                                                }
                                            }

                                        @endphp
                                    @endif
                                </td>
                                <td>{{$event->event_date_display}}</td>
                                <td>
                                    @if($event->location_url)
                                        <a target="_blank" class="btn btn-sm btn-success" href="{{$event->location_url }}">Visit Location</a>
                                    @else
                                        N/A
                                    @endif
                                </td>
                                <td>
                                    <a href="javascript:void(0);" onclick="deleteItem({{$event->id}},'{{route('saved.event.delete',$event->id)}}')"
                                       class="btn btn-danger btn-circle">
                                        <i class="fa fa-trash-o"></i>
                                    </a>
                                 </td>
                            </tr>
                            @endforeach
                            @else
                                <tr>
                                    <td colspan="10" class="text-center text-danger">No record found</td>
                                </tr>
                            @endif
                        </table>
                        {{ $saved_events->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('footer')

@endsection