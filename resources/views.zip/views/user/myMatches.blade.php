@extends('layouts.master')

@section('main-content')
<!-- Start Main Content ---->
<div class="maincontent">
    <div class="content bgwhite">                       

        <!-- Start Upgrade Membership ---->
        <div class="membership">
            <div class="container-fluid">
                <h4 class="font22"><b class="vertical_align"><img src="{{ asset('backend/images/mymatch.png') }}" alt="" class="all_users"><span>MY MATCHES</span></b></h4>
            </div>
        </div>
        <hr>
        @if ( !isthisSubscribed() && !getmanualfeatures('token_view_my_matches_'))
            @include('includes.debitTokens', ['featurevalue'=>'token_monthly_connection_value_','featureclass'=>'chat','featurename'=>'token_view_my_matches_', 'featureMessage'=>'Hey '. ucfirst( Auth::user()->name ) .'!. Upgrade your membership today to experience unlimited chat.'])
    	@endif
        <!-- End Upgrade Membership ---->
        <!-- Start Match Tabs -->
        <div class="matchtabs pt30">
            <div class="container-fluid">
                <div class="col-md-12 mb30">
                    @if ( isthisSubscribed() || getmanualfeatures('token_view_my_matches_'))
                        @if( $matches )
                            @foreach( $matches as $match )
                                 @php
                                    $userid = $match->user_id;
                                    if( $match->user_id == Auth::user()->id ){
                                        $userid = $match->matcher_id;
                                    }
                                    $userdata = \App\User::find($userid);
                                    $profilepic = (@$userdata->profile_pic )? 'uploads/'.$userdata->profile_pic : 'images/default.png';
                                @endphp
                                @if( $userdata )
                                <a href="{{ ucfirst( $userdata->name ) }}" data-toggle="modal" data-target="#myModal">
                                    <div class="col-md-2 text-center matches" data-user="{{$userid}}" table-id="{{ $match->id }}">
                                        <div class="img_container" style="background-image:url({{ asset($profilepic) }})"></div>
                                        @if( $userdata->is_online )
                                            <span class="green"></span>
                                        @endif
                                        <div class="mtop20">
                                            <h4>
                                            <a href="javascript:void(0)" data ="{{ ucfirst( $userdata->name ) }}">{{ ucfirst( $userdata->name ) }}</a>
                                            </h4>
                                            <span>{{ @$userdata->usergroup->title }}</span>
                                        </div>
                                    </div>
                                </a>
                                @endif
                            @endforeach
                        @endif
                    @endif
                </div>   
            </div>
        </div>
        <!-- End Match Tabs -->

    </div>      
</div>

<script>
    $(document).ready(function(){
        $(".matches").click(function(){
            $('#trialid').val($(this).attr('table-id'));
            var userid = $(this).data('user');
            var imgSrc = $(this).find('img').attr('src');
            var href = $(this).find('a').attr('href');
            var popup = $("#myModal");
            popup.find("#macher_id").val(userid);
            popup.find(".macher_image").attr("src", imgSrc);
            popup.find(".matcher_name").text(href);
        });
    });
</script>
<!-- End Main Content ---->
@endsection
@section('footer')
    @include('modals/trials-modals')
@endsection