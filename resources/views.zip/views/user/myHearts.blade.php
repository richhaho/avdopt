@extends('layouts.master')

@section('main-content')
<!-- Start Main Content ---->
<div class="maincontent">
    <div class="content bgwhite">                       

        <!-- Start Upgrade Membership ---->
        <div class="membership">
            <div class="container-fluid">
                <h4 class="font16 vertical_align"><b><i style="font-size:22px" class="fa fa-heart"></i> Hearts</b></h4>
            </div>
        </div>
        @if ( !isthisSubscribed() )
            <div class="row upgrade">
    			<div class="col-md-10">
    				<div class="upgdinfo bggray font300">
    					<p>Hey {{ ucfirst( Auth::user()->name ) }}!. Upgrade your membership today to check your Hearts.</p>
    				</div>
    			</div>
    			<div class="col-md-2">							
        			<a style="padding: 18px 0px;" href="{{ url('pricing') }}" class="btn btnred width100">Upgrade Membership</a>
    			</div>
    		</div>
    	@endif
        <!-- End Upgrade Membership ---->
        <!-- Start Match Tabs -->
        @if ( isthisSubscribed() )
            <div class="matchtabs pt30">
                <div class="container-fluid">
                    <div class="col-md-12 mb30">
                        @if( $hearts )
                            @foreach( $hearts as $heart )
                                @php
                                    $userdata = \App\User::find($heart->wishlistedby);
                                    $profilepic = ( @$userdata->profile_pic )? 'uploads/'.$userdata->profile_pic : 'images/default.png';
                                @endphp
                                @if( $userdata )
                                <a href="{{route('viewprofile', base64_encode( $heart->wishlistedby ))}}">
                                <div class="col-md-2 text-center">
                                    <img src="{{ asset($profilepic) }}" alt="">
                                    @if( $userdata->is_online )
                                        <span class="green"></span>
                                    @endif
                                    <div class="mtop20">
                                        <h4><a href="{{ route('viewprofile', base64_encode($heart->wishlistedby)) }}">{{ ucfirst( $userdata->name ) }}</a></h4>
                                        <span>{{ @$userdata->usergroup->title }}</span>
                                    </div>
                                </div>
                                </a>
                                @endif
                            @endforeach
                        @endif
                    </div>   
                </div>
            </div>
        @endif
        <!-- End Match Tabs -->

    </div>      
</div>
<!-- End Main Content ---->
@endsection