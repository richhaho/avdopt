@extends('layouts.master')

@section('main-content')
<!-- Start Main Content ---->
<div class="maincontent">
    <div class="content bgwhite">                       

        <!-- Start Upgrade Membership ---->
        <div class="membership">
            <div class="container-fluid">
                <h4 class="font22 inline_block"><b class="vertical_align"><img class=" all_users" alt=" Img" src="/backend/images/mylike.png"> Likes</b></h4>
            </div>
        </div>
        <hr>
        @if ( !isthisSubscribed() )
            <div class="row mtop30 upgrade">
    			<div class="col-md-10">
    				<div class="upgdinfo bggray font300">
    					<p>Hey {{ ucfirst( Auth::user()->name ) }}!. Upgrade your membership today to check your likes.</p>
    				</div>
    			</div>
    			<div class="col-md-2">							
        			<a style="padding: 18px 0px;" href="{{ url('pricing') }}" class="btn btnred width100">Upgrade Membership</a>
    			</div>
    		</div>
    	@endif
        <!-- End Upgrade Membership ---->
        <!-- Start Match Tabs -->
        @if ( isthisSubscribed() )
            <div class="myliketab mtop30 pt30">
                <div class="container-fluid">
                    <div class="col-md-12 mb30">
                        @if( $likes )
                            @foreach( $likes as $userid )
                                @php
                                    $userdata = \App\User::find($userid);
                                    $profilepic = ( @$userdata->profile_pic )? 'uploads/'.$userdata->profile_pic : 'images/default.png';
                                @endphp
                                @if( $userdata )
                                <a href="{{route('viewprofile', base64_encode( $userid ))}}">
                                <div class="col-md-2 text-center">
                                    <div class="img_container" style="background-image:url({{ asset($profilepic) }});"></div>
                                    @if( $userdata->is_online )
                                        <span class="green"></span>
                                    @endif
                                    <div class="mtop20">
                                        <h4><a href="{{ route('viewprofile', base64_encode($userid)) }}">{{ ucfirst( $userdata->name ) }}</a></h4>
                                        <span>{{ @$userdata->usergroup->title }}</span>
                                    </div>
                                </div>
                                </a>
                                @endif
                            @endforeach
                        @endif
                    </div>   
                </div>
            </div>
        @endif
        <!-- End Match Tabs -->

    </div>      
</div>
<!-- End Main Content ---->
@endsection