<div style="    max-width: 600px;width: 100%;margin: 20px auto;text-align: center;padding: 20px;font-size: 22px;box-shadow: 1px 1px 11px #6f6d6d;border-radius: 9px;border: 1px solid #ccc;">
Hello, someone send you a message on Adovt.
<p>Click to the <a style="background: red;color: #fff;text-decoration: none;padding: 2px 20px;border-radius: 4px;" href="{{ url('chat')}}">Link</a>, to view message.</p>
<p>Thanks</p>

</div>