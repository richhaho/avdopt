<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="{{ asset('backend/js/custom.js') }}"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/ticket.css') }}" rel="stylesheet">
    <script type="text/javascript">
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
            'url' => url('/'),
        ]); ?>
    </script>
</head>
<body>
    <div id="app-ticket">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a href="{{ url('/') }}"><img title="Adoption" alt="Adoption" src="{{ asset('images/logo.jpg') }}"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <div class="topuser">
        					<ul>
            					<li class="userimg" style="background:url({{url('/uploads/'.Auth::user()->profile_pic)}})"></li>
            					<li><div class="username">{{ Auth::user()->name }}<i class="fa fa-angle-down"></i></div>
            						<div class="submenu">
            							<ul>
            								<li><a href="/profile">Profile</a></li>
            								<li><a class="dropdown-item" href="{{ route('logout') }}"
            									onclick="event.preventDefault();
            									document.getElementById('logout-form').submit();">
            									{{ __('Logout') }}
            								</a>
            
            								<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
            									@csrf
            								</form></li>
            							</ul>
            						</div>			
            					</li>
            				</ul>					
        				</div>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4 ticket_main">
            @yield('content')
        </main>
    </div>
    @yield('footer')
    </script>
    <style>
.topuser .submenu {
        right: -40px;
    top: 61px;
    }
    .submenu.showsbmenu {
    z-index: 9999;
    opacity: 1;
    visibility: visible;
}
</style>
</body>
</html>
