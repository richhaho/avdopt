@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">                       
        
        <!-- Start Upgrade Membership ---->
        <div class="">
            <div class="container-fluid">
                @if(session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <h4 class="inline_block font22"><b class="vertical_align"><img src="{{ asset('backend/images/message.png') }}" alt="Report" title="Img" class="all_users">Message</b></h4> 
                <button type="button" class="btn btnred pull-right leave_note" data-toggle="modal" data-id="1" data-target="#myModalNote">Compose</button>
                <hr>
                @if ( !isthisSubscribed() )
                <div class="row mtop30 upgrade">
                    <div class="col-md-10">
                        <div class="upgdinfo bggray font300">
                            <p>Hey John! It will cost 1 token to open a conversation withi Amy. Upgrade your membership to send ullimited messages</p>
                        </div>
                    </div>
                    <div class="col-md-2">                          
                       	<a style="padding: 18px 0px;" href="{{ url('pricing') }}" class="btn btnred width100">Upgrade Membership</a>
                    </div>
                </div>
                @endif
                <div class="row">
                    <div class="col-md-12">
                        
                    </div>
                </div>
            </div>
             <hr>
        </div>
        
        <!-- End Upgrade Membership ---->
        @if ( isthisSubscribed() )
        <form method="post" action="{{ route('messages.delete') }}">
            @csrf
            <input type="hidden" value="" id="ids" name="ids">
            <input type="hidden" value="1" id="getcolumn" name="getcolumn">
            <input type="submit" id="fire" style="visibility: hidden;">
        </form>
        <ul class="actionbtns">
            <li style="display:none" class="deletebtn"><a href="javascript:void(0)" class="btn btnred btnpad ml20">Trash</a></li>
        </ul>
        
        <!-- Start Message Tabs -->
        <div class="msgtabs pt50">
            <div class="container-fluid">

                <ul class="tablist">
                    <li class="active"><a data-toggle="tab" href="#inbox">Inbox</a></li>
                    <li><a data-toggle="tab" href="#sent">Sent</a></li>
                    <li><a data-toggle="tab" href="#drafts">Drafts</a></li>
                    <li><a data-toggle="tab" href="#trash">Trash</a></li>
                </ul>

                <div class="tab-content">
                    <div id="inbox" class="tab-pane fade in active">
                        
                        @foreach($inboxmessages as $inboxmessage)
                            <div class="tabrow">
                                <div class="row">
                                    <div class="col-md-3 col-sm-3">
                                        <label>
                                            <input type="checkbox" value="{{ $inboxmessage->id }}" name="inboxmessage[]" />
                                            <i></i>
                                        </label>
                                        {{ $inboxmessage->user->name }}
                                    </div>
                                    <div class="col-md-6 col-sm-6">{{ $inboxmessage->message }}</div>
                                    <div class="col-md-3 col-sm-3 text-right">{{ $inboxmessage->created_at->format('H:i A') }}</div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div id="sent" class="tab-pane fade">
                         @foreach($sentmessages as $sentmessage)
                            <div class="tabrow">
                                <div class="row">
                                    <div class="col-md-3 col-sm-3">
                                        <label>
                                            <input type="checkbox" value="{{ $sentmessage->id }}" name="inboxmessage[]" />
                                            <i></i>
                                        </label>
                                        {{ $sentmessage->reciever->name }}
                                    </div>
                                    <div class="col-md-6 col-sm-6">{{ $sentmessage->message }}</div>
                                    <div class="col-md-3 col-sm-3 text-right">{{ $sentmessage->created_at->format('H:i A') }}</div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div id="drafts" class="tab-pane fade">
                                                 
                    </div>
                    <div id="trash" class="tab-pane fade">
                       @foreach($trashmessages as $trashmessage)
                            <div class="tabrow">
                                <div class="row">
                                    <div class="col-md-3 col-sm-3">
                                        <label>
                                            <input type="checkbox" value="{{ $trashmessage->id }}" name="inboxmessage[]" />
                                            <i></i>
                                        </label>
                                        {{ $trashmessage->user->name }}
                                    </div>
                                    <div class="col-md-6 col-sm-6">{{ $trashmessage->message }}</div>
                                    <div class="col-md-3 col-sm-3 text-right">{{ $trashmessage->created_at->format('H:i A') }}</div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
        @endif
        <!-- End Message Tabs -->

    </div>      
</div>

 <div class="modal fade" id="myModalNote">
      <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h2 class="modal-title inline_block">Send Message</h2>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        @php
        $matches = App\Match::WhereRaw( ' is_match = 1 AND ( user_id = ' . Auth::user()->id .' OR  matcher_id = ' . Auth::user()->id .' )' )
				->get();
				@endphp
        <!-- Modal body -->
        <div class="modal-body">
            <input type="hidden" value="{{ ucfirst( Auth::user()->id ) }}" name="reciever_id" />
            <div class="form-group">
                @if($matches)
                    <label class="col-form-label">Select User</label>
                    <select name="reciever_ids[]" id="reciever_ids" class="form-control searchdropdown" multiple>
                        @foreach($matches as $match)
                            <option value="{{ $match->matcher_id }}">{{ $match->match->name }}</option>
                        @endforeach
                    </select>
                @endif
                <label class="col-form-label mtop20">Message</label>
                <input type="hidden" id="hiddenid" value="0">
                <select name="note" id="noteselect" class="form-control">
                    @php
                        $notes = App\Note::where('user_group', Auth::user()->group)->get();
                        foreach($notes as $note){
                            echo '<option value="'.$note->note.'">'.$note->note.'</option>';
                        }
                    @endphp
                    @if ( isthisSubscribed() )
                        <option value="other">Other</option>
                     @endif
                </select>
                @if ( isthisSubscribed() )
                    <div class="textareanote"></div>
                @else
                    
                @endif
                <br>
            </div>
            <div class="form-group">
                <label></label>
            <button id="subbtn" style="text-transform:capitalize" class="btnpad btnred border_radius">Send</button>
            </div>
        </div>

      </div>
    </div>
  </div>
@endsection

@section('footer')
<script type="text/javascript">

$(document).ready(function(){
    $("#noteselect").change(function(){
        var selectvalue = $("#noteselect option:selected").val();
        if(selectvalue=='other'){
            $(this).remove();
            $('.textareanote').append('<textarea type="text" class="form-control" name="note"></textarea>');
        }
    });
    
    $("ul.tablist li").click(function(){
        $(".tab-content input").prop('checked', false);
         $('#ids').val(' ');
    });
    $("#inbox input, #sent input, #drafts input").change(function() {
        var checkboxes = [];
        $('.tab-content input:checked').each(function () {
            checkboxes.push($(this).val());
        });
        $('#ids').val(checkboxes);
        if ($(".tab-content input:checkbox:checked").length > 0){
            $('.deletebtn').show();
        }
        else{
            $('.deletebtn').hide();
        }
    });
    $(".deletebtn").click(function(){
        $('#fire').trigger('click');
        
    });
    $(".tablist li").click(function(){
        $('#getcolumn').val('');
    });
    $(".tablist li:first-child").click(function(){
        $('#getcolumn').val('1');
    });
     $(".tablist li:nth-child(2)").click(function(){
        $('#getcolumn').val('2');
    });
    $("#trash input").change(function() {
        var checkboxes = [];
        $('.tab-content input:checked').each(function () {
            checkboxes.push($(this).val());
        });
        $('#ids').val(checkboxes);
        if ($(".tab-content input:checkbox:checked").length > 0){
            $('.deletebtn a').text('Restore');
            $('.deletebtn').show();
            $('#getcolumn').val('3');
        }
        else{
            $('.deletebtn').hide();
        }
    });
});  
</script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.searchdropdown').select2({
          multiple: true
        });
    });
</script>
@endsection

