@extends('layouts.master')
@section('htmlheader')
<link rel="stylesheet" type="text/css" href="{{ asset('css/slick.css') }}"/><link rel="stylesheet" type="text/css" href="http://kenwheeler.github.io/slick/slick/slick-theme.css"/>
<script type="text/javascript" src="{{ asset('js/slick.js') }}"></script>
@endsection
@section('main-content')
<div class="maincontent backend">
    <div class="content bgwhite"> 
            <div class="container-fluid">
                <h4 class="font22"><b class="vertical_align"><img src="{{ asset('backend/images/trial.png') }}" alt="" class="all_users"><span>TRIAL REQUESTS</span></b></h4>
                <hr class="mb30">
                <ul class="tablist trialrequest">
                    <li class="active"><a data-toggle="tab" href="#recieved">New</a></li>
                    <li><a data-toggle="tab" href="#accepted">Accepted</a></li>
                    <li><a data-toggle="tab" href="#sent">Sent</a></li>
                    <li><a data-toggle="tab" href="#decline">Decline</a></li>
                    <li><a data-toggle="tab" href="#ratings">Ratings</a></li>
                </ul>
                <div class="tab-content" >
                    <div id="recieved" class="tab-pane fade in active">
                        <table>
                            @if($recieved)
                                @foreach($recieved as $request)
                                    <tr> 
                                        <td>{{ $request->userid->name }}, Sent request to you</td> 
                                        <td>
                                            <a class="btn btn-success btn-circle btn-xs" href="{{ route('trials.accept', $request->id) }}">Accept</a> 
                                            <a class="btn btn-danger btn-circle btn-xs" href="{{ route('trials.decline', $request->id) }}">Cancel</a>
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </table>
                    </div>
                    <div id="accepted" class="tab-pane fade">
                        <table class="table">
                            @if($accepted)
                                @foreach($accepted as $request)
                                    <tr> 
                                        <td>You trial request accpeted by, {{ $request->userid->name }}, <small>{{ $request->userid->created_at }} </small> </td>
                                        <td>

                                            <a class="btn btn-info btn-circle"  data-toggle="modal" data-target="#myModal" data-id="1" link="{{ route('trials.success', $request->id) }}">Successfull</a>
                                            <a class="btn btn-danger btn-circle"  data-toggle="modal" data-target="#myModal" data-id="2" link="{{ route('trials.unsuccess', $request->id) }}">Unsuccessfull</a>
                                        </td> 
                                    </tr>
                                @endforeach
                            @endif
                        </table>
                    </div>
                    <div id="sent" class="tab-pane fade">
                        <table>
                            @if($sent)
                                @foreach($sent as $request)
                                    <tr> 
                                        <td>You sent request to {{ $request->matcherid->name }}, on <code>{{  $request->created_at->toFormattedDateString() }}</code> </td>
                                        <td>
                                            <a class="btn btn-danger btn-circle" href="{{ route('trials.cancelrequest', $request->id) }}">Cancel Request</a>
                                        </td> 
                                    </tr>
                                @endforeach
                            @endif
                        </table>
                    </div>
                    <div id="decline" class="tab-pane fade">
                        <ul>
                            @if($decline)
                                @foreach($decline as $request)
                                    <li> you decline {{ $request->userid->name }} </li>
                                @endforeach
                            @endif
                        </ul>
                    </div>
                    <div id="ratings" class="tab-pane fade">
                        <table class="table table-hover">
                            <tr>
                                <th>#</th>
                                <th>Ratings</th>
                                <th>Comments</th>
                            </tr>
                            @foreach($ratings as $rating)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>
                                        @for ($i = 1; $i <= $rating->rating; $i++)
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                        @endfor
                                    </td>
                                    <td>{{ $rating->comment }}</td>
                                </tr>
                            @endforeach
                        </table>
                    </div>
                </div>
            </div>
      
    </div>
</div>


<div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Rate Us</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <form action="" method="post" id="forsucccess">
              @csrf
              <div class="form-group">
                   <div class="row">
                    <label for="name" class="col-md-4 col-form-label text-md-right">Rating</label>
                    <input type="hidden" id="hiddenval" value="">
                    <div class="col-md-8">
                        <select id="rating" class="form-control" name="rating">
                            <option value="1">1 Star</option>
                            <option value="2">2 Star</option>
                            <option value="3">3 Star</option>
                            <option value="4">4 Star</option>
                            <option value="5">5 Star</option>
                        </select>
    
                    </div>
                    </div>
              </div>
              
              <div class="form-group">
                   <div class="row">
                    <label for="name" class="col-md-4 col-form-label text-md-right">Comment</label>
    
                    <div class="col-md-8">
                        <textarea class="form-control" name="comment"></textarea>
                    </div>
                    </div>
              </div>
              <button class="btn btn-danger btn-circle pull-right">Submit</button>
          </form>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
        </div>
        
      </div>
    </div>
  </div>
@endsection

@section('footer')
<script type="text/javascript">
    $(document).ready(function(){
        $('#accepted .btn').click(function(){
            var href = $(this).attr('link');
            var id = $(this).attr('data-id');
            $('#forsucccess').attr('action',href);
            $('#hiddenval').val(id);
        });
    });
</script>
@endsection