@extends('layouts.master')

@section('main-content')
<div class="maincontent">
    <div class="content bgwhite">                       
        @if(session()->has('success'))
            <div class="alert alert-success">
                {{ session()->get('success') }}
            </div>
        @endif
        @if(session()->has('danger'))
            <div class="alert alert-danger">
                {{ session()->get('danger') }}
            </div>
        @endif
        <!-- Start Upgrade Membership ---->
			<div class="membership">
				<div class="container-fluid">
					<h4 class="font22"><b class="vertical_align"><img src="{{ URL::to('/') }}/backend/images/wallet-icon.png" class="all_users"><span>MY WALLET</span></b></h4>
					<div class="row padding15 border mtopbottom20 vertical_align">
						<div class="col-md-3 col-sm-3 mtopbottom20 vertical_align">
							<div class="col-md-2 col-sm-2 font300">
								<img src="{{ URL::to('/') }}/backend/images/wallet-icon.png">
							</div>
							<div class="col-md-10 col-sm-10 font300">
								<h4 class="font20"><b>T{{ ( @$wallet->balance )? $wallet->balance : 0 }}</b></h4>
								<p>in Your Wallet Balance</p>
							</div>
						</div>
						<div class="col-md-5 col-sm-6">
							<div class="upgdinfo  font300">
								<input type="text" class="amount" placeholder="Enter Amount to be Added in Wallet">
							</div>
						</div>
						<div class="col-md-4 col-sm-3 text-right">							
							<button class="btnred btnpad border_radius">Upgrade Membership</button>
							<a href="{{ url('payment/credit') }}" class="btnred btnpad border_radius">Add Token</a>
						</div>
					</div>
				</div>
			</div>
			<!-- End Upgrade Membership ---->

			<!-- Start Message Tabs -->
			<div class="msgtabs pt30">
				<div class="container-fluid">
                   <h4 class="font18 mb"><b class="vertical_align"><img src="{{ URL::to('/') }}/backend/images/transaction.png" class="all_users"><span>TRANSACTIONS</span></b></h4>
						<div  class="tabl mtopbottom">
							<div class="tablerow active">
								<div class="row">
									<div class="col-md-2 col-sm-2"><h4>DATE</h4></div>
									<div class="col-md-2 col-sm-2"><h4>TRANSACTIONS ID</h4></div>
									<div class="col-md-2 col-sm-2"><h4>DEPOSIT</h4></div>
									<div class="col-md-4 col-sm-4"><h4>ORDER</h4></div>
									<div class="col-md-2 col-sm-2"><h4>BALANCE</h4></div>
								</div>
							</div>
							@foreach ($transactions as $transaction)
								<div class="tablerow">
									<div class="row">
										<div class="col-md-2 col-sm-2"><h4>{{ date('m-d-Y h:i:A', strtotime( $transaction->created_at ) )  }}</h4></div>
										<div class="col-md-2 col-sm-2"><h4>{{ $transaction->hash }}</h4></div>
										<div class="col-md-2 col-sm-2"><h4>{{ $transaction->type }}</h4></div>
										<div class="col-md-4 col-sm-4"><h4>{{ $transaction->meta['description'] }}</div>
										<div class="col-md-2 col-sm-2"><h4>T{{ $transaction->amount }}</h4></div>
									</div>
								</div>
							@endforeach
							
							


						</div>
						
				</div>
			</div>
			<!-- End Message Tabs -->

    </div>      
</div>
@endsection
